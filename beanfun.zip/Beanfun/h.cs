﻿using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Text;

// Token: 0x02000014 RID: 20
internal static class h
{
	
	[DllImport("user32.dll", SetLastError = true)]
	public static extern IntPtr FindWindow(string A_0, string A_1);


	[DllImport("user32.dll", SetLastError = true)]
	public static extern uint GetWindowThreadProcessId(IntPtr A_0, out int A_1);

	
	[DllImport("user32.dll")]
	public static extern bool SetForegroundWindow(IntPtr A_0);


	[DllImport("user32.dll")]
	public static extern byte MapVirtualKey(byte A_0, int A_1);

	
	public static void a(IntPtr A_0, string A_1)
	{
		foreach (byte a_ in Encoding.ASCII.GetBytes(A_1))
		{
			h.PostMessage(A_0, 258U, (int)a_, 0);
		}
	}

	
	public static void a(IntPtr A_0, uint A_1, byte A_2)
	{
		h.PostMessage(A_0, A_1, (int)A_2, (int)h.MapVirtualKey(A_2, 0) << 17);
	}

	[DllImport("user32.dll")]
	public static extern int PostMessage(IntPtr A_0, uint A_1, int A_2, int A_3);

	
	[DllImport("user32.dll")]
	public static extern bool ClientToScreen(IntPtr A_0, ref Point A_1);

	
	[DllImport("user32.dll")]
	public static extern bool GetCursorPos(ref Point A_0);

	
	[DllImport("user32.dll")]
	public static extern int SetCursorPos(int A_0, int A_1);

	
	[DllImport("kernel32.dll", CharSet = CharSet.Auto)]
	private static extern int GetSystemDefaultLocaleName([Out] StringBuilder A_0, int A_1);

	
	public static string a()
	{
		StringBuilder stringBuilder = new StringBuilder(85);
		if (h.GetSystemDefaultLocaleName(stringBuilder, 85) > 0)
		{
			return stringBuilder.ToString();
		}
		return null;
	}

	
	[DllImport("kernel32.dll")]
	public static extern IntPtr GetCurrentProcess();

	
	[DllImport("kernel32.dll", CharSet = CharSet.Auto)]
	public static extern IntPtr GetModuleHandle(string A_0);

	
	[DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
	public static extern IntPtr GetProcAddress(IntPtr A_0, [MarshalAs(UnmanagedType.LPStr)] string A_1);

	
	[DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
	[return: MarshalAs(UnmanagedType.Bool)]
	public static extern bool IsWow64Process(IntPtr A_0, out bool A_1);

	
	[DllImport("Kernel32.dll")]
	public static extern bool AttachConsole(int A_0);

	
	public const int m_a = 85;
}
