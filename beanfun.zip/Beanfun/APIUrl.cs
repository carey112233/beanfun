﻿using System;

namespace Beanfun
{
		public enum APIUrl
	{
				GetSk,
				GetRc,
				CreRl,
				CreLl
	}
}
