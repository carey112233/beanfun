﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

namespace Beanfun
{
		public partial class Contract : Window, IComponentConnector
	{
				public Contract()
		{
			this.InitializeComponent();
			
		}

	

	}
}
