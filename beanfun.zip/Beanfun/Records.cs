﻿using System;
using System.Collections.Generic;

namespace Beanfun
{
	// Token: 0x0200003C RID: 60
	[Serializable]
	internal class Records
	{
		// Token: 0x0600016A RID: 362 RVA: 0x00008C10 File Offset: 0x00006E10
		public static Records a(object A_0)
		{
			Records records = new Records();
			if (A_0 is AccountRecords)
			{
				AccountRecords accountRecords = (AccountRecords)A_0;
				records.regionList = accountRecords.regionList;
				records.accountList = accountRecords.accountList;
				records.passwdList = accountRecords.passwdList;
				records.verifyList = accountRecords.verifyList;
				records.methodList = accountRecords.methodList;
				records.autoLoginList = accountRecords.autoLoginList;
			}
			return records;
		}

		// Token: 0x0600016B RID: 363 RVA: 0x00008C7B File Offset: 0x00006E7B
		public Records()
		{
		}

		// Token: 0x04000105 RID: 261
		public List<string> regionList;

		// Token: 0x04000106 RID: 262
		public List<string> accountList;

		// Token: 0x04000107 RID: 263
		public List<string> accountNameList;

		// Token: 0x04000108 RID: 264
		public List<string> passwdList;

		// Token: 0x04000109 RID: 265
		public List<string> verifyList;

		// Token: 0x0400010A RID: 266
		public List<int> methodList;

		// Token: 0x0400010B RID: 267
		public List<bool> autoLoginList;
	}
}
