﻿using System;
using System.Diagnostics;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Markup;

namespace Beanfun
{
    public partial class MapleTools : Window, IComponentConnector
	{

		public MapleTools()
		{
			this.InitializeComponent();

			
				Full.Text = Fulluri();
				Little.Text = UpdataUri();
			
		}

        BeanfunClient bf = new BeanfunClient();

		
		private void updataclick(object A_0, MouseButtonEventArgs A_1)//
		{
			try
			{

				Clipboard.SetDataObject(Little.Text);
			}
			catch
			{
			}
		}
		private void li(object A_0, RoutedEventArgs A_1)//升级按钮
		{
            bf.processstart(UpdataUri());
			//System.Diagnostics.Process.Start(UpdataUri());
		}

		private void fullclick(object A_0, MouseButtonEventArgs A_1)//完整版按钮
		{
			try
			{

				Clipboard.SetDataObject(Full.Text);
			}
			catch
			{
			}
		}
		private string UpdataUri()//升级包安装地址
		{
			try
			{
				WebClient web = new WebClient();
				Uri uri = new Uri("https://gitee.com/Carey1223/bean-men/blob/master/README.md");
				string s = Encoding.UTF8.GetString(web.DownloadData(uri));
				Regex regex = new Regex("版本升级安装地址：(.*)结束3");
				if (!regex.IsMatch(s))
				{ }
				string response;
				response = regex.Match(s).Groups[1].Value;
				return response;
			}
			catch { return null; }
			
		}
	
		private void fu(object A_0, RoutedEventArgs A_1)
		{

            bf.processstart(Fulluri());
        }

		

		private string Fulluri()//完整版安装地址
		{
			try
			{
				WebClient web = new WebClient();
				Uri uri = new Uri("https://gitee.com/Carey1223/bean-men/blob/master/README.md");
				string s = Encoding.UTF8.GetString(web.DownloadData(uri));
				Regex regex = new Regex("完整版安装地址：(.*)结束n");
				if (!regex.IsMatch(s))
				{ }
				string response;
				response = regex.Match(s).Groups[1].Value;
				return response;
			}
			catch { return null; }
		
		}
	

	}

}
