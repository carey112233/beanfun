﻿using System;
using System.IO;
using System.Net;
using System.Runtime.CompilerServices;

// Token: 0x02000010 RID: 16
internal class d : WebClient
{
	// Token: 0x06000042 RID: 66 RVA: 0x00002CD7 File Offset: 0x00000ED7
	public d() : this(30000)
	{
	}

	// Token: 0x06000043 RID: 67 RVA: 0x00002CE4 File Offset: 0x00000EE4
	public d(int A_0)
	{
		this.a(A_0);
	}

	// Token: 0x06000044 RID: 68 RVA: 0x00002CF3 File Offset: 0x00000EF3
	[CompilerGenerated]
	public int a()
	{
		return this.m_a;
	}

	// Token: 0x06000045 RID: 69 RVA: 0x00002CFB File Offset: 0x00000EFB
	[CompilerGenerated]
	public void a(int A_0)
	{
		this.m_a = A_0;
	}

	// Token: 0x06000046 RID: 70 RVA: 0x00002D04 File Offset: 0x00000F04
	protected override WebRequest GetWebRequest(Uri address)
	{
		WebRequest webRequest = base.GetWebRequest(address);
		webRequest.Timeout = this.a();
		return webRequest;
	}

	// Token: 0x06000047 RID: 71 RVA: 0x00002D1C File Offset: 0x00000F1C
	public MemoryStream a(string A_0)
	{
		A_0 = A_0 + "?random=" + new Random().Next(0, int.MaxValue).ToString();
		return new MemoryStream(base.DownloadData(A_0));
	}

	// Token: 0x06000048 RID: 72 RVA: 0x00002D5A File Offset: 0x00000F5A
	public MemoryStream a(Uri A_0)
	{
		return this.a(A_0.ToString());
	}

	// Token: 0x04000048 RID: 72
	[CompilerGenerated]
	private int m_a;
}
