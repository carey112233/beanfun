﻿using System;
using System.Runtime.CompilerServices;

namespace Beanfun
{
		public class SKIV
	{
				
		public string Skey
		{
			[CompilerGenerated]
			get
			{
				return this.a;
			}
			[CompilerGenerated]
			set
			{
				this.a = value;
			}
		}

				
		public string IV
		{
			[CompilerGenerated]
			get
			{
				return this.b;
			}
			[CompilerGenerated]
			set
			{
				this.b = value;
			}
		}

			
		public string APPuid
		{
			[CompilerGenerated]
			get
			{
				return this.c;
			}
			[CompilerGenerated]
			set
			{
				this.c = value;
			}
		}

			
		public string bfAPPuid
		{
			[CompilerGenerated]
			get
			{
				return this.d;
			}
			[CompilerGenerated]
			set
			{
				this.d = value;
			}
		}

				
		public int ClientID
		{
			[CompilerGenerated]
			get
			{
				return this.e;
			}
			[CompilerGenerated]
			set
			{
				this.e = value;
			}
		}

		public string ReturnValue
		{
			[CompilerGenerated]
			get
			{
				return this.f;
			}
			[CompilerGenerated]
			set
			{
				this.f = value;
			}
		}

			
		public string ReturnMessage
		{
			[CompilerGenerated]
			get
			{
				return this.g;
			}
			[CompilerGenerated]
			set
			{
				this.g = value;
			}
		}

				public SKIV()
		{
		}

				[CompilerGenerated]
		private string a;

				[CompilerGenerated]
		private string b;

				[CompilerGenerated]
		private string c;

				[CompilerGenerated]
		private string d;

				[CompilerGenerated]
		private int e;

				[CompilerGenerated]
		private string f;

				[CompilerGenerated]
		private string g;
	}
}
