﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Media.Imaging;
using FluorineFx;
using Newtonsoft.Json.Linq;

namespace Beanfun
{
    // Token: 0x0200003F RID: 63
    public class BeanfunClient : WebClient
    {
        public void processstart(String uri)
        {
            string path = "";
            if (System.Diagnostics.Process.GetProcessesByName("maplestory").ToList().Count<= 0)
            {
                System.Diagnostics.Process.Start(uri);
            }
            else
            {
                try { System.Diagnostics.Process.Start("firefox.exe", uri); }
                catch
                {
                    try { System.Diagnostics.Process.Start("chrome.exe", uri); }
                    catch
                    {
                        if (System.Diagnostics.Process.GetProcessesByName("360se").ToList().Count > 0)
                        {

                            Process[] ps = Process.GetProcessesByName("360se");
                            foreach (Process p in ps)
                            {
                                try
                                {
                                    path = p.MainModule.FileName.ToString();
                                }
                                catch { }
                                try { System.Diagnostics.Process.Start(path, uri); }
                                catch { }
                                return;

                            }

                        }
                        if (System.Diagnostics.Process.GetProcessesByName("QQBrowser").ToList().Count > 0)
                        {
                            Process[] ps = Process.GetProcessesByName("QQBrowser");
                            foreach (Process p in ps)
                            {
                                try
                                {
                                    path = p.MainModule.FileName.ToString();
                                }
                                catch { }
                                try { System.Diagnostics.Process.Start(path, uri); }
                                catch { }
                                return;

                            }


                        }
                        if (System.Diagnostics.Process.GetProcessesByName("TSBrowser").ToList().Count > 0)
                        {
                            Process[] ps = Process.GetProcessesByName("TSBrowser");
                            foreach (Process p in ps)
                            {
                                try
                                {
                                    path = p.MainModule.FileName.ToString();
                                }
                                catch { }
                                try
                                {
                                    System.Diagnostics.Process.Start(path, uri);
                                }

                                catch { }


                                return;
                            }

                         
                         }
                        if (System.Diagnostics.Process.GetProcessesByName("sougouexplorer").ToList().Count > 0)
                        {
                            Process[] ps = Process.GetProcessesByName("sougouexplorer");
                            foreach (Process p in ps)
                            {
                                try
                                {
                                    path = p.MainModule.FileName.ToString();
                                }
                                catch { }
                                try { System.Diagnostics.Process.Start(path, uri); }
                                catch { }
                                return;

                            }
                        }
                        if (System.Diagnostics.Process.GetProcessesByName("2345explorer").ToList().Count > 0)
                        {
                            Process[] ps = Process.GetProcessesByName("2345explorer");
                            foreach (Process p in ps)
                            {
                                try
                                {
                                    path = p.MainModule.FileName.ToString();
                                }
                                catch { }
                                try { System.Diagnostics.Process.Start(path, uri); }
                                catch { }
                                return;

                            }
                        }
                        if (System.Diagnostics.Process.GetProcessesByName("UCBrowser").ToList().Count > 0)
                        {
                            Process[] ps = Process.GetProcessesByName("UCBrowser");
                            foreach (Process p in ps)
                            {
                                try
                                {
                                    path = p.MainModule.FileName.ToString();
                                }
                                catch { }
                                try { System.Diagnostics.Process.Start(path, uri); }
                                catch { }
                                return;

                            }


                        }

                        else { System.Diagnostics.Process.Start("iexplore.exe", uri); }
                    }
                }
            }
               

        }

        // Token: 0x06000182 RID: 386 RVA: 0x00009920 File Offset: 0x00007B20
        public void GetAccounts(string service_code, string service_region, bool fatal = true)
        {
            if (this.m_d == null)
            {
                return;
            }
            bool flag;
            string uri;
            if ((service_code == "610153" && service_region == "TN") || (service_code == "610085" && service_region == "TC"))
            {
                flag = true;
                uri = string.Concat(new string[]
                {
                    "https://tw.beanfun.com/TW/auth.aspx?channel=accounts_management&page_and_query=01.aspx%3FServiceCode%3D",
                    service_code,
                    "%26ServiceRegion%3D",
                    service_region,
                    "&web_token=",
                    this.m_d
                });
            }
            else
            {
                flag = false;
                uri = string.Concat(new string[]
                {
                    "https://tw.beanfun.com/beanfun_block/auth.aspx?channel=game_zone&page_and_query=game_start.aspx%3Fservice_code_and_region%3D",
                    service_code,
                    "_",
                    service_region,
                    "&web_token=",
                    this.m_d
                });
            }
            string text = this.DownloadString(uri);
            Regex regex;
            if (flag)
            {
                regex = new Regex("<span id=\"lblGameMaxAccount\" style=\"([^\"]*)\">(.*)</span>");
                if (regex.IsMatch(text))
                {
                    this.accountAmountLimitNotice = "最多新增账号数:" + regex.Match(text).Groups[2].Value;
                }
                else
                {
                    this.accountAmountLimitNotice = "";
                }
                text = this.DownloadString("https://tw.beanfun.com/TW/accounts_management/01Accounts.aspx");
                if (text.Contains("點我前往完成進階認證"))
                {
                    this.accountAmountLimitNotice = "请完成进阶认证";
                }
                regex = new Regex("<td class=\"game\" align=\"left\">(.*)</td><td class=\"game\">");
                this.accountList.Clear();
                //using (IEnumerator enumerator = regex.Matches(text).GetEnumerator())
                //{
                //	while (enumerator.MoveNext())
                //	{
                //		object obj = enumerator.Current;
                //		Match match = (Match)obj;
                //		this.accountList.Add(new BeanfunClient.ServiceAccount(true, null, null, match.Groups[1].Value, null));
                //	}
                //	goto IL_33D;
                //}
            }
        }

            // Token: 0x06000183 RID: 387 RVA: 0x00009CE0 File Offset: 0x00007EE0
            private string d(string A_0, string A_1, string A_2)
        {
            string result;
            try
            {
                string input = this.DownloadString(string.Concat(new string[]
                {
                    "https://tw.beanfun.com/beanfun_block/game_zone/game_start_step2.aspx?service_code=",
                    A_0,
                    "&service_region=",
                    A_1,
                    "&sotp=",
                    A_2,
                    "&dt=",
                    this.a(2)
                }));
                Regex regex = new Regex("ServiceAccountCreateTime: \"([^\"]+)\"");
                if (!regex.IsMatch(input))
                {
                    result = null;
                }
                else
                {
                    result = regex.Match(input).Groups[1].Value;
                }
            }
            catch
            {
                result = null;
            }
            return result;
        }
        public GameServerAccountListApp gameServAccListApp;

        // Token: 0x06000184 RID: 388 RVA: 0x00009D80 File Offset: 0x00007F80
        public void GetAccounts_HK(string service_code, string service_region, bool fatal = true)
        {
            this.DownloadString(string.Concat(new string[]
           {
                "https://hk.beanfun.com/beanfun_block/auth.aspx?channel=game_zone&page_and_query=game_start.aspx%3Fservice_code_and_region%3D",
                service_code,
                "_",
                service_region,
                "&token=",
                this.m_a.Token
           }));
            string input = this.DownloadString("https://hk.beanfun.com/beanfun_block/game_zone/game_server_account_list.aspx?service_code=" + service_code + "&service_region=" + service_region);
            Regex regex = new Regex(string.Concat(new string[]
            {
                "<li class=\"([^\"]*)\" title=\"([^\"]*)\" onclick=\"StartGame\\('",
                service_code,
                "', '",
                service_region,
                "', '(\\w+)', '(\\d+)', '([^\"]*)', '(\\w+)', '([^\"]+)'\\)"
            }));
            this.accountList.Clear();
            foreach (object obj in regex.Matches(input))
            {
                Match match = (Match)obj;
                if (!(match.Groups[3].Value == "") && !(match.Groups[4].Value == "") && !(match.Groups[5].Value == "") && !(match.Groups[7].Value == ""))
                {
                    Match match2 = new Regex("(\\d+)/(\\d+)/(\\d+) (.*)").Match(match.Groups[7].Value);
                    this.accountList.Add(new BeanfunClient.ServiceAccount(!match.Groups[1].Value.ToLower().Equals("stop"), match.Groups[3].Value, match.Groups[4].Value, WebUtility.HtmlDecode(match.Groups[5].Value), string.Concat(new string[]
                    {
                        match2.Groups[3].Value,
                        "-",
                        match2.Groups[2].Value,
                        "-",
                        match2.Groups[1].Value,
                        " ",
                        match2.Groups[4].Value
                    })));
                }
            }
            regex = new Regex("<div id=\"divServiceAccountAmountLimitNotice\" class=\"InnerContent\">(.*)</div>");
            if (regex.IsMatch(input))
            {
                this.accountAmountLimitNotice = regex.Match(input).Groups[1].Value;
            }
            else
            {
                this.accountAmountLimitNotice = "";
            }
            if (this.accountList.Count > 0)
            {
                this.accountList.Sort(new Comparison<BeanfunClient.ServiceAccount>(BeanfunClient.C.m_c.b));
            }
            this.errmsg = null;
        }

        // Token: 0x06000185 RID: 389 RVA: 0x0000A080 File Offset: 0x00008280
        private NameValueCollection a(string A_0, string A_1)
        {
            string input;
            if (App.LoginRegion == "TW")
            {
                string uri = string.Concat(new string[]
                {
                    "https://tw.beanfun.com/TW/auth.aspx?channel=accounts_management&page_and_query=01.aspx%3FServiceCode%3D",
                    A_0,
                    "%26ServiceRegion%3D",
                    A_1,
                    "&web_token=",
                    this.m_d
                });
                input = this.DownloadString(uri);
            }
            else
            {
                string uri = string.Concat(new string[]
                {
                    "http://hk.beanfun.com/beanfun_web_ap/auth.aspx?channel=accounts_management&page_and_query=01.aspx%3FServiceCode%3D",
                    A_0,
                    "%26ServiceRegion%3D",
                    A_1,
                    "&token=",
                    this.m_a.Token
                });
                input = this.DownloadString(uri);
            }
            Regex regex = new Regex("id=\"__VIEWSTATE\" value=\"(.*)\" />");
            if (!regex.IsMatch(input))
            {
                this.errmsg = "LoginNoViewstate";
                return null;
            }
            string value = regex.Match(input).Groups[1].Value;
            regex = new Regex("id=\"__VIEWSTATEGENERATOR\" value=\"(.*)\" />");
            if (!regex.IsMatch(input))
            {
                this.errmsg = "LoginNoViewstategenerator";
                return null;
            }
            string value2 = regex.Match(input).Groups[1].Value;
            regex = new Regex("id=\"__PREVIOUSPAGE\" value=\"(.*)\" />");
            if (!regex.IsMatch(input))
            {
                this.errmsg = "LoginNoPreviouspage";
                return null;
            }
            string value3 = regex.Match(input).Groups[1].Value;
            regex = new Regex("id=\"__EVENTVALIDATION\" value=\"(.*)\" />");
            if (!regex.IsMatch(input))
            {
                this.errmsg = "LoginNoEventvalidation";
                return null;
            }
            string value4 = regex.Match(input).Groups[1].Value;
            return new NameValueCollection
            {
                {
                    "__VIEWSTATE",
                    value
                },
                {
                    "__VIEWSTATEGENERATOR",
                    value2
                },
                {
                    "__PREVIOUSPAGE",
                    value3
                },
                {
                    "__EVENTVALIDATION",
                    value4
                }
            };
        }

        // Token: 0x06000186 RID: 390 RVA: 0x0000A240 File Offset: 0x00008440
        public NameValueCollection UnconnectedGame_InitAddAccountPayload(string service_code, string service_region)
        {
            NameValueCollection nameValueCollection = this.a(service_code, service_region);
            nameValueCollection.Add("__EVENTTARGET", "");
            nameValueCollection.Add("__EVENTARGUMENT", "");
            nameValueCollection.Add("imgbtn_AddAccount.x", "0");
            nameValueCollection.Add("imgbtn_AddAccount.y", "0");
            string text;
            if (App.LoginRegion == "TW")
            {
                text = this.UploadString("https://tw.beanfun.com/TW/accounts_management/02.aspx", nameValueCollection);
            }
            else
            {
                text = this.UploadString("http://hk.beanfun.com/beanfun_web_ap/accounts_management/02.aspx", nameValueCollection);
            }
            Regex regex = new Regex("id=\"__VIEWSTATE\" value=\"(.*)\" />");
            if (!regex.IsMatch(text))
            {
                this.errmsg = "LoginNoViewstate";
                return null;
            }
            string value = regex.Match(text).Groups[1].Value;
            regex = new Regex("id=\"__VIEWSTATEGENERATOR\" value=\"(.*)\" />");
            if (!regex.IsMatch(text))
            {
                this.errmsg = "LoginNoViewstategenerator";
                return null;
            }
            string value2 = regex.Match(text).Groups[1].Value;
            regex = new Regex("id=\"__EVENTVALIDATION\" value=\"(.*)\" />");
            if (!regex.IsMatch(text))
            {
                this.errmsg = "LoginNoEventvalidation";
                return null;
            }
            string value3 = regex.Match(text).Groups[1].Value;
            nameValueCollection.Clear();
            nameValueCollection.Add("__VIEWSTATE", value);
            nameValueCollection.Add("__VIEWSTATEGENERATOR", value2);
            nameValueCollection.Add("__EVENTVALIDATION", value3);
            regex = new Regex("<span id=\"lblGameName\">(.*)</span>");
            if (!regex.IsMatch(text))
            {
                this.errmsg = "LoginNoGameName";
                return null;
            }
            nameValueCollection.Add("GameName", regex.Match(text).Groups[1].Value);
            regex = new Regex("<span id=\"lblAccountLen\">(.*)</span>");
            if (!regex.IsMatch(text))
            {
                this.errmsg = "LoginNoAccountLen";
                return null;
            }
            nameValueCollection.Add("AccountLen", regex.Match(text).Groups[1].Value);
            nameValueCollection.Add("CheckNickName", text.Contains("<a id=\"lbtnCheckNickName\"") ? "1" : "");
            return nameValueCollection;
        }

        // Token: 0x06000187 RID: 391 RVA: 0x0000A448 File Offset: 0x00008648
        public NameValueCollection UnconnectedGame_AddAccountCheck(string service_code, string service_region, string name, string txtServiceAccountDN, NameValueCollection payload)
        {
            if (payload == null)
            {
                return null;
            }
            payload.Add("__EVENTTARGET", "lbtnCheckAccount");
            payload.Add("__EVENTARGUMENT", "");
            payload.Add("txtServiceAccountID", name);
            if (txtServiceAccountDN != null)
            {
                if (App.LoginRegion == "TW")
                {
                    payload.Add("t1", txtServiceAccountDN);
                }
                else
                {
                    payload.Add("txtServiceAccountDN", txtServiceAccountDN);
                }
            }
            payload.Add("txtNewPwd", "");
            payload.Add("txtNewPwd2", "");
            string input;
            if (App.LoginRegion == "TW")
            {
                input = this.UploadString("https://tw.beanfun.com/TW/accounts_management/02.aspx", payload);
            }
            else
            {
                input = this.UploadString("http://hk.beanfun.com/beanfun_web_ap/accounts_management/02.aspx", payload);
            }
            Regex regex = new Regex("id=\"__VIEWSTATE\" value=\"(.*)\" />");
            if (!regex.IsMatch(input))
            {
                this.errmsg = "LoginNoViewstate";
                return null;
            }
            string value = regex.Match(input).Groups[1].Value;
            regex = new Regex("id=\"__VIEWSTATEGENERATOR\" value=\"(.*)\" />");
            if (!regex.IsMatch(input))
            {
                this.errmsg = "LoginNoViewstategenerator";
                return null;
            }
            string value2 = regex.Match(input).Groups[1].Value;
            regex = new Regex("id=\"__EVENTVALIDATION\" value=\"(.*)\" />");
            if (!regex.IsMatch(input))
            {
                this.errmsg = "LoginNoEventvalidation";
                return null;
            }
            string value3 = regex.Match(input).Groups[1].Value;
            payload.Clear();
            payload.Add("__VIEWSTATE", value);
            payload.Add("__VIEWSTATEGENERATOR", value2);
            payload.Add("__EVENTVALIDATION", value3);
            regex = new Regex("<span id=\"lblErrorMessage\" style=\"color:Red;\">(.*)</span>");
            payload.Add("lblErrorMessage", regex.IsMatch(input) ? regex.Match(input).Groups[1].Value : "");
            return payload;
        }

        // Token: 0x06000188 RID: 392 RVA: 0x0000A62C File Offset: 0x0000882C
        public NameValueCollection UnconnectedGame_AddAccountCheckNickName(string service_code, string service_region, string txtServiceAccountDN, NameValueCollection payload)
        {
            if (payload == null)
            {
                return null;
            }
            payload.Add("__EVENTTARGET", "lbtnCheckNickName");
            payload.Add("__EVENTARGUMENT", "");
            payload.Add("txtServiceAccountID", "");
            if (txtServiceAccountDN != null)
            {
                if (App.LoginRegion == "TW")
                {
                    payload.Add("t1", txtServiceAccountDN);
                }
                else
                {
                    payload.Add("txtServiceAccountDN", txtServiceAccountDN);
                }
            }
            payload.Add("txtNewPwd", "");
            payload.Add("txtNewPwd2", "");
            string input;
            if (App.LoginRegion == "TW")
            {
                input = this.UploadString("https://tw.beanfun.com/TW/accounts_management/02.aspx", payload);
            }
            else
            {
                input = this.UploadString("http://hk.beanfun.com/beanfun_web_ap/accounts_management/02.aspx", payload);
            }
            Regex regex = new Regex("id=\"__VIEWSTATE\" value=\"(.*)\" />");
            if (!regex.IsMatch(input))
            {
                this.errmsg = "LoginNoViewstate";
                return null;
            }
            string value = regex.Match(input).Groups[1].Value;
            regex = new Regex("id=\"__VIEWSTATEGENERATOR\" value=\"(.*)\" />");
            if (!regex.IsMatch(input))
            {
                this.errmsg = "LoginNoViewstategenerator";
                return null;
            }
            string value2 = regex.Match(input).Groups[1].Value;
            regex = new Regex("id=\"__EVENTVALIDATION\" value=\"(.*)\" />");
            if (!regex.IsMatch(input))
            {
                this.errmsg = "LoginNoEventvalidation";
                return null;
            }
            string value3 = regex.Match(input).Groups[1].Value;
            payload.Clear();
            payload.Add("__VIEWSTATE", value);
            payload.Add("__VIEWSTATEGENERATOR", value2);
            payload.Add("__EVENTVALIDATION", value3);
            regex = new Regex("<span id=\"lblErrorMessage\" style=\"color:Red;\">(.*)</span>");
            payload.Add("lblErrorMessage", regex.IsMatch(input) ? regex.Match(input).Groups[1].Value : "");
            return payload;
        }

        // Token: 0x06000189 RID: 393 RVA: 0x0000A810 File Offset: 0x00008A10
        public string UnconnectedGame_AddAccount(string service_code, string service_region, string name, string txtNewPwd, string txtNewPwd2, string txtServiceAccountDN, NameValueCollection payload)
        {
            if (name == null || name == "")
            {
                return null;
            }
            if (txtNewPwd == null || txtNewPwd == "")
            {
                return null;
            }
            if (txtNewPwd2 == null || txtNewPwd2 == "")
            {
                return null;
            }
            if (payload == null)
            {
                return null;
            }
            payload.Add("__EVENTTARGET", "");
            payload.Add("__EVENTARGUMENT", "");
            payload.Add("txtServiceAccountID", name);
            if (txtServiceAccountDN != null)
            {
                if (App.LoginRegion == "TW")
                {
                    payload.Add("t1", txtServiceAccountDN);
                }
                else
                {
                    payload.Add("txtServiceAccountDN", txtServiceAccountDN);
                }
            }
            payload.Add("txtNewPwd", txtNewPwd);
            payload.Add("txtNewPwd2", txtNewPwd2);
            payload.Add("chkBox1", "on");
            payload.Add("imgbtn_Submit.x", "0");
            payload.Add("imgbtn_Submit.y", "0");
            string input;
            if (App.LoginRegion == "TW")
            {
                input = this.UploadString("https://tw.beanfun.com/TW/accounts_management/02.aspx", payload);
            }
            else
            {
                input = this.UploadString("http://hk.beanfun.com/beanfun_web_ap/accounts_management/02.aspx", payload);
            }
            Regex regex = new Regex("<span id=\"lblErrorMessage\" style=\"color:Red;\">(.*)</span>");
            if (!regex.IsMatch(input))
            {
                return "";
            }
            return regex.Match(input).Groups[1].Value;
        }

        // Token: 0x0600018A RID: 394 RVA: 0x0000A970 File Offset: 0x00008B70
        public string UnconnectedGame_ChangePassword(string service_code, string service_region, int num, string txtEmail)
        {
            this.a(service_code, service_region);
            string input;
            if (App.LoginRegion == "TW")
            {
                input = this.DownloadString("https://tw.beanfun.com/TW/accounts_management/01Accounts.aspx");
            }
            else
            {
                input = this.DownloadString("http://hk.beanfun.com/beanfun_web_ap/accounts_management/01Accounts.aspx");
            }
            Regex regex = new Regex("id=\"__VIEWSTATE\" value=\"(.*)\" />");
            if (!regex.IsMatch(input))
            {
                this.errmsg = "LoginNoViewstate";
                return null;
            }
            string value = regex.Match(input).Groups[1].Value;
            regex = new Regex("id=\"__VIEWSTATEGENERATOR\" value=\"(.*)\" />");
            if (!regex.IsMatch(input))
            {
                this.errmsg = "LoginNoViewstategenerator";
                return null;
            }
            string value2 = regex.Match(input).Groups[1].Value;
            regex = new Regex("id=\"__EVENTVALIDATION\" value=\"(.*)\" />");
            if (!regex.IsMatch(input))
            {
                this.errmsg = "LoginNoEventvalidation";
                return null;
            }
            string value3 = regex.Match(input).Groups[1].Value;
            NameValueCollection nameValueCollection = new NameValueCollection();
            nameValueCollection.Add("__VIEWSTATE", value);
            nameValueCollection.Add("__VIEWSTATEGENERATOR", value2);
            nameValueCollection.Add("__EVENTVALIDATION", value3);
            nameValueCollection.Add("__EVENTTARGET", "gvServiceAccountList");
            nameValueCollection.Add("__EVENTARGUMENT", "ChangePassword$" + num.ToString());
            nameValueCollection.Add("x", "0");
            nameValueCollection.Add("y", "0");
            if (App.LoginRegion == "TW")
            {
                input = this.UploadString("https://tw.beanfun.com/TW/accounts_management/01Accounts.aspx", nameValueCollection);
                input = this.DownloadString("https://tw.beanfun.com/TW/accounts_management/03.aspx");
            }
            else
            {
                input = this.UploadString("http://hk.beanfun.com/beanfun_web_ap/accounts_management/01Accounts.aspx", nameValueCollection);
                input = this.DownloadString("http://hk.beanfun.com/beanfun_web_ap/accounts_management/03.aspx");
            }
            regex = new Regex("id=\"__VIEWSTATE\" value=\"(.*)\" />");
            if (!regex.IsMatch(input))
            {
                this.errmsg = "LoginNoViewstate";
                return null;
            }
            value = regex.Match(input).Groups[1].Value;
            regex = new Regex("id=\"__VIEWSTATEGENERATOR\" value=\"(.*)\" />");
            if (!regex.IsMatch(input))
            {
                this.errmsg = "LoginNoViewstategenerator";
                return null;
            }
            value2 = regex.Match(input).Groups[1].Value;
            regex = new Regex("id=\"__EVENTVALIDATION\" value=\"(.*)\" />");
            if (!regex.IsMatch(input))
            {
                this.errmsg = "LoginNoEventvalidation";
                return null;
            }
            value3 = regex.Match(input).Groups[1].Value;
            nameValueCollection.Clear();
            nameValueCollection.Add("__VIEWSTATE", value);
            nameValueCollection.Add("__VIEWSTATEGENERATOR", value2);
            nameValueCollection.Add("__EVENTVALIDATION", value3);
            nameValueCollection.Add("txtEmail", txtEmail);
            nameValueCollection.Add("imgbtn_Submit.x", "0");
            nameValueCollection.Add("imgbtn_Submit.y", "0");
            regex = new Regex("<span id=\"lblErrorMessage\" style=\"color:Red;\">(.*)</span>");
            if (App.LoginRegion == "TW")
            {
                input = this.UploadString("https://tw.beanfun.com/TW/accounts_management/03.aspx", nameValueCollection);
                string result = regex.IsMatch(input) ? regex.Match(input).Groups[1].Value : "";
                if (result != "")
                {
                    return result;
                }
                regex = new Regex("verify_code=(.*)");
                if (!regex.IsMatch(this.m_c.ToString()))
                {
                    return null;
                }
                return "verify_code" + regex.Match(this.m_c.ToString()).Groups[1].Value;
            }
            else
            {
                input = this.UploadString("http://hk.beanfun.com/beanfun_web_ap/accounts_management/03.aspx", nameValueCollection);
                string text = regex.IsMatch(input) ? regex.Match(input).Groups[1].Value : null;
                if (text == null || text == "")
                {
                    return null;
                }
                regex = new Regex("確認碼：(.*)");
                if (!regex.IsMatch(text))
                {
                    return text;
                }
                return "verify_code" + regex.Match(text).Groups[1].Value;
            }
        }

        // Token: 0x0600018B RID: 395 RVA: 0x0000AD64 File Offset: 0x00008F64
        public bool AddServiceAccount(string name, string service_code, string service_region)
        {
            if (name == null || name == "")
            {
                return false;
            }
            NameValueCollection nameValueCollection = new NameValueCollection();
            nameValueCollection.Add("strFunction", "AddServiceAccount");
            nameValueCollection.Add("npsc", "");
            nameValueCollection.Add("npsr", "");
            nameValueCollection.Add("sc", service_code);
            nameValueCollection.Add("sr", service_region);
            nameValueCollection.Add("sadn", name);
            nameValueCollection.Add("sag", "");
            string text = this.UploadString(string.Concat(new string[]
            {
                "https://",
                App.LoginRegion.ToLower(),
                ".beanfun.com/",
                (App.LoginRegion == "HK") ? "beanfun_block/" : "",
                "generic_handlers/gamezone.ashx"
            }), nameValueCollection);
            if (text == "")
            {
                return false;
            }
            JObject jobject = JObject.Parse(text);
            return jobject["intResult"] != null && (int)jobject["intResult"] == 1;
        }

        // Token: 0x0600018C RID: 396 RVA: 0x0000AE80 File Offset: 0x00009080
        public bool ChangeServiceAccountDisplayName(string newName, string gameCode, BeanfunClient.ServiceAccount account)
        {
            if (newName == null || newName == "" || account == null || newName == account.sname)
            {
                return false;
            }
            NameValueCollection nameValueCollection = new NameValueCollection();
            nameValueCollection.Add("strFunction", "ChangeServiceAccountDisplayName");
            nameValueCollection.Add("sl", gameCode);
            nameValueCollection.Add("said", account.sid);
            nameValueCollection.Add("nsadn", newName);
            string text = this.UploadString(string.Concat(new string[]
            {
                "https://",
                App.LoginRegion.ToLower(),
                ".beanfun.com/",
                (App.LoginRegion == "HK") ? "beanfun_block/" : "",
                "generic_handlers/gamezone.ashx"
            }), nameValueCollection);
            if (text == "")
            {
                return false;
            }
            JObject jobject = JObject.Parse(text);
            return jobject["intResult"] != null && (int)jobject["intResult"] == 1;
        }

        // Token: 0x0600018D RID: 397 RVA: 0x0000AF80 File Offset: 0x00009180
        public string GetServiceContract(string service_code, string service_region)
        {
            NameValueCollection nameValueCollection = new NameValueCollection();
            nameValueCollection.Add("strFunction", "GetServiceContract");
            nameValueCollection.Add("sc", service_code);
            nameValueCollection.Add("sr", service_region);
            string text = this.UploadStringGZip(string.Concat(new string[]
            {
                "https://",
                App.LoginRegion.ToLower(),
                ".beanfun.com/",
                (App.LoginRegion == "HK") ? "beanfun_block/" : "",
                "generic_handlers/gamezone.ashx"
            }), nameValueCollection);
            if (text == "")
            {
                return "";
            }
            JObject jobject = JObject.Parse(text);
            if (jobject["intResult"] == null || (int)jobject["intResult"] != 1)
            {
                return "";
            }
            return (string)jobject["strResult"];
        }

        // Token: 0x17000016 RID: 22
        // (get) Token: 0x0600018E RID: 398 RVA: 0x0000B063 File Offset: 0x00009263
        // (set) Token: 0x0600018F RID: 399 RVA: 0x0000B06B File Offset: 0x0000926B
        int i;
        public int Timeout
        {
            [CompilerGenerated]
            get
            {
                return this.i;
            }
            [CompilerGenerated]
            set
            {
                this.i = value;
            }
        }

        // Token: 0x17000017 RID: 23
        // (get) Token: 0x06000190 RID: 400 RVA: 0x0000B074 File Offset: 0x00009274
        public string WebToken
        {
            get
            {
                return this.m_d;
            }
        }

        // Token: 0x17000018 RID: 24
        // (get) Token: 0x06000191 RID: 401 RVA: 0x0000B07C File Offset: 0x0000927C
        public BFServiceX BFServ
        {
            get
            {
                return this.m_a;
            }
        }

        // Token: 0x06000192 RID: 402 RVA: 0x0000B084 File Offset: 0x00009284
        public BeanfunClient()
        {
            this.m_f = true;
            this.m_b = new CookieContainer();
            base.Headers.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36");
            base.Headers.Set("Accept-Encoding", "identity");
            base.Encoding = Encoding.UTF8;
            this.m_c = null;
            this.errmsg = null;
            this.m_d = null;
            this.m_e = null;
            this.accountList = new List<BeanfunClient.ServiceAccount>();
            this.accountAmountLimitNotice = "";
            this.Timeout = 30000;
            
        }

        // Token: 0x06000193 RID: 403 RVA: 0x0000B114 File Offset: 0x00009314
        public string DownloadString(string Uri, Encoding Encoding)
        {
            base.Headers.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36");
            base.Headers.Set("Accept-Encoding", "identity");
            return Encoding.GetString(base.DownloadData(Uri));
        }

        // Token: 0x06000194 RID: 404 RVA: 0x0000B14D File Offset: 0x0000934D
        public new string DownloadString(string Uri)
        {
            base.Headers.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36");
            base.Headers.Set("Accept-Encoding", "identity");
            return base.DownloadString(Uri);
        }

        // Token: 0x06000195 RID: 405 RVA: 0x0000B180 File Offset: 0x00009380
        public string UploadString(string skey, NameValueCollection payload)
        {
            base.Headers.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36");
            base.Headers.Set("Accept-Encoding", "identity");
            return Encoding.UTF8.GetString(base.UploadValues(skey, payload));
        }

        // Token: 0x06000196 RID: 406 RVA: 0x0000B1C0 File Offset: 0x000093C0
        public string UploadStringGZip(string skey, NameValueCollection payload)
        {
            base.Headers.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36");
            base.Headers.Set("Accept-Encoding", "gzip, deflate, br");
            byte[] array = base.UploadValues(skey, payload);
            if (array.Length == 0)
            {
                return "";
            }
            if (array[0] == 31 && array[1] == 139)
            {
                Stream stream = new MemoryStream(array);
                MemoryStream memoryStream = new MemoryStream();
                GZipStream gzipStream = new GZipStream(stream, CompressionMode.Decompress);
                byte[] array2 = new byte[1000];
                int count;
                while ((count = gzipStream.Read(array2, 0, array2.Length)) > 0)
                {
                    memoryStream.Write(array2, 0, count);
                }
                array = memoryStream.ToArray();
            }
            return Encoding.UTF8.GetString(array);
        }

        // Token: 0x06000197 RID: 407 RVA: 0x0000B26C File Offset: 0x0000946C
        protected override WebRequest GetWebRequest(Uri address)
        {
          
            HttpWebRequest httpWebRequest = base.GetWebRequest(address) as HttpWebRequest;
            httpWebRequest.Timeout = this.Timeout;
            if (httpWebRequest != null)
            {
                httpWebRequest.CookieContainer = this.m_b;
                httpWebRequest.AllowAutoRedirect = this.m_f;
            }
            return httpWebRequest;
        }

        // Token: 0x06000198 RID: 408 RVA: 0x0000B2B0 File Offset: 0x000094B0
        protected override WebResponse GetWebResponse(WebRequest request)
        {
            WebResponse webResponse = base.GetWebResponse(request);
            this.m_c = webResponse.ResponseUri;
            return webResponse;
        }

        // Token: 0x06000199 RID: 409 RVA: 0x0000B2D2 File Offset: 0x000094D2
        public CookieCollection GetCookies()
        {
            return this.m_b.GetCookies(new Uri("https://" + App.LoginRegion.ToLower() + ".beanfun.com/"));
        }

        // Token: 0x0600019A RID: 410 RVA: 0x0000B300 File Offset: 0x00009500
        private string a(string A_0)
        {
            foreach (object obj in this.GetCookies())
            {
                Cookie cookie = (Cookie)obj;
                if (cookie.Name == A_0)
                {
                    return cookie.Value;
                }
            }
            return null;
        }

        // Token: 0x0600019B RID: 411 RVA: 0x0000B36C File Offset: 0x0000956C
        private string a(int A_0 = 0)
        {
            DateTime now = DateTime.Now;
            if (A_0 == 1)
            {
                return (now.Year - 1900).ToString() + (now.Month - 1).ToString() + now.ToString("ddHHmmssfff");
            }
            if (A_0 != 2)
            {
                return now.ToString("yyyyMMddHHmmss.fff");
            }
            return now.Year.ToString() + (now.Month - 1).ToString() + now.ToString("ddHHmmssfff");
        }

        // Token: 0x0600019C RID: 412 RVA: 0x0000B400 File Offset: 0x00009600
        public void Ping()
        {
            try
            {
                string str;
                if (App.LoginRegion == "TW")
                {
                    str = base.Encoding.GetString(base.DownloadData("https://tw.beanfun.com/beanfun_block/generic_handlers/echo_token.ashx?webtoken=1"));
                }
                else
                {
                    if (this.m_a == null)
                    {
                        return;
                    }
                    str = this.DownloadString("http://hk.beanfun.com/beanfun_block/generic_handlers/echo_token.ashx?token=" + this.m_a.Token);
                }
                Console.WriteLine(this.a(0) + " @ " + str);
            }
            catch
            {
            }
        }

        // Token: 0x0600019D RID: 413 RVA: 0x0000B48C File Offset: 0x0000968C
        public int getRemainPoint()
        {
            string uri = "https://tw.beanfun.com/beanfun_block/generic_handlers/get_remain_point.ashx?webtoken=1";
            if (App.LoginRegion == "HK")
            {
                uri = "http://hk.beanfun.com/beanfun_block/generic_handlers/get_remain_point.ashx?token=" + this.m_a.Token;
            }
            string input = this.DownloadString(uri);
            int result;
            try
            {
                Regex regex = new Regex("\"RemainPoint\" : \"(.*)\" }");
                if (regex.IsMatch(input))
                {
                    result = int.Parse(regex.Match(input).Groups[1].Value);
                }
                else
                {
                    result = 0;
                }
            }
            catch
            {
                result = 0;
            }
            return result;
        }

        // Token: 0x0600019E RID: 414 RVA: 0x0000B520 File Offset: 0x00009720
        public string getEmail()
        {
            if (App.LoginRegion == "HK")
            {
                return "";
            }
            base.Headers.Set("Referer", "https://tw.beanfun.com/");
            string input = this.DownloadString("https://tw.beanfun.com/beanfun_block/loader.ashx?service_code=999999&service_region=T0");
            Regex regex = new Regex("BeanFunBlock.LoggedInUserData.Email = \"(.*)\";BeanFunBlock.LoggedInUserData.MessageCount");
            if (regex.IsMatch(input))
            {
                return regex.Match(input).Groups[1].Value;
            }
            return "";
        }

        // Token: 0x0600019F RID: 415 RVA: 0x0000B598 File Offset: 0x00009798
        private string c(string A_0, string A_1, string A_2)
        {
            string result;
            try
            {
                string input = this.DownloadString("http://hk.beanfun.com/beanfun_block/login/id-pass_form.aspx?otp1=" + A_2 + "&seed=0");
                Regex regex = new Regex("id=\"__VIEWSTATE\" value=\"(.*)\" />");
                if (!regex.IsMatch(input))
                {
                    this.errmsg = "LoginNoViewstate";
                    result = null;
                }
                else
                {
                    string value = regex.Match(input).Groups[1].Value;
                    regex = new Regex("id=\"__EVENTVALIDATION\" value=\"(.*)\" />");
                    if (!regex.IsMatch(input))
                    {
                        this.errmsg = "LoginNoEventvalidation";
                        result = null;
                    }
                    else
                    {
                        string value2 = regex.Match(input).Groups[1].Value;
                        regex = new Regex("id=\"__VIEWSTATEGENERATOR\" value=\"(.*)\" />");
                        if (!regex.IsMatch(input))
                        {
                            this.errmsg = "LoginNoViewstateGenerator";
                            result = null;
                        }
                        else
                        {
                            string value3 = regex.Match(input).Groups[1].Value;
                            NameValueCollection nameValueCollection = new NameValueCollection();
                            nameValueCollection.Add("__EVENTTARGET", "");
                            nameValueCollection.Add("__EVENTARGUMENT", "");
                            nameValueCollection.Add("__VIEWSTATE", value);
                            nameValueCollection.Add("__VIEWSTATEGENERATOR", value3);
                            nameValueCollection.Add("__EVENTVALIDATION", value2);
                            nameValueCollection.Add("t_AccountID", A_0);
                            nameValueCollection.Add("t_Password", A_1);
                            nameValueCollection.Add("btn_login.x", "0");
                            nameValueCollection.Add("btn_login.y", "0");
                            nameValueCollection.Add("recaptcha_response_field", "manual_challenge");
                            input = this.UploadString("http://hk.beanfun.com/beanfun_block/login/id-pass_form.aspx?otp1=" + A_2 + "&seed=0", nameValueCollection);
                            regex = new Regex("ProcessLoginV2\\((.*)\\);\\\"");
                            if (!regex.IsMatch(input))
                            {
                                this.errmsg = "LoginNoProcessLoginV2JSON";
                                result = null;
                            }
                            else
                            {
                                string text = regex.Match(input).Groups[1].Value.Replace("\\", "");
                                this.m_a.Token = (string)JObject.Parse(text)["token"];
                                result = "true";
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                this.errmsg = "LoginUnknown\n\n" + ex.Message + "\n" + ex.StackTrace;
                result = null;
            }
            return result;
        }

        // Token: 0x060001A0 RID: 416 RVA: 0x0000B7F0 File Offset: 0x000099F0
        private string b(string A_0, string A_1, string A_2)
        {
            string result;
            try
            {
                string text = this.DownloadString("https://tw.newlogin.beanfun.com/login/id-pass_form.aspx?skey=" + A_2);
                Regex regex = new Regex("id=\"__VIEWSTATE\" value=\"(.*)\" />");
                if (!regex.IsMatch(text))
                {
                    this.errmsg = "LoginNoViewstate";
                    result = null;
                }
                else
                {
                    string value = regex.Match(text).Groups[1].Value;
                    regex = new Regex("id=\"__EVENTVALIDATION\" value=\"(.*)\" />");
                    if (!regex.IsMatch(text))
                    {
                        this.errmsg = "LoginNoEventvalidation";
                        result = null;
                    }
                    else
                    {
                        string value2 = regex.Match(text).Groups[1].Value;
                        regex = new Regex("id=\"__VIEWSTATEGENERATOR\" value=\"(.*)\" />");
                        if (!regex.IsMatch(text))
                        {
                            this.errmsg = "LoginNoViewstateGenerator";
                            result = null;
                        }
                        else
                        {
                            string value3 = regex.Match(text).Groups[1].Value;
                            regex = new Regex("id=\"LBD_VCID_c_login_idpass_form_samplecaptcha\" value=\"(.*)\" />");
                            if (!regex.IsMatch(text))
                            {
                                this.errmsg = "LoginNoSamplecaptcha";
                                result = null;
                            }
                            else
                            {
                                string value4 = regex.Match(text).Groups[1].Value;
                                string value5 = "";
                                regex = new Regex("isHideCaptcha\\s?=\\s?false");
                                if (regex.IsMatch(text))
                                {
                                    CaptchaWnd captchaWnd;
                                    (captchaWnd = new CaptchaWnd(this, value4)).ShowDialog();
                                    if (captchaWnd == null)
                                    {
                                        this.errmsg = "LoginInitCaptcha";
                                        return null;
                                    }
                                    value5 = captchaWnd.Captcha;
                                }
                                NameValueCollection nameValueCollection = new NameValueCollection();
                                nameValueCollection.Add("__EVENTTARGET", "");
                                nameValueCollection.Add("__EVENTARGUMENT", "");
                                nameValueCollection.Add("__VIEWSTATE", value);
                                nameValueCollection.Add("__VIEWSTATEGENERATOR", value3);
                                nameValueCollection.Add("__EVENTVALIDATION", value2);
                                nameValueCollection.Add("t_AccountID", A_0);
                                nameValueCollection.Add("t_Password", A_1);
                                nameValueCollection.Add("CodeTextBox", value5);
                                nameValueCollection.Add("LBD_VCID_c_login_idpass_form_samplecaptcha", value4);
                                nameValueCollection.Add("btn_login", "登入");
                                text = this.UploadString("https://tw.newlogin.beanfun.com/login/id-pass_form.aspx?skey=" + A_2, nameValueCollection);
                                if (text.Contains("RELOAD_CAPTCHA_CODE") && text.Contains("alert"))
                                {
                                    this.errmsg = "LoginAdvanceCheck";
                                    result = null;
                                }
                                else
                                {
                                    regex = new Regex("akey=(.*)");
                                    if (!regex.IsMatch(this.m_c.ToString()))
                                    {
                                        this.errmsg = "LoginNoAkey";
                                        regex = new Regex("<script type=\"text/javascript\">\\$\\(function\\(\\){MsgBox.Show\\('(.*)'\\);}\\);</script>");
                                        if (regex.IsMatch(text))
                                        {
                                            this.errmsg = regex.Match(text).Groups[1].Value;
                                        }
                                        else
                                        {
                                            regex = new Regex("pollRequest\\(\"([^\"]*)\",\"(\\w+)\",\"([^\"]+)\"\\);");
                                            if (regex.IsMatch(text))
                                            {
                                                this.errmsg = regex.Match(text).Groups[1].Value + "\",\"" + regex.Match(text).Groups[3].Value;
                                                this.m_g = regex.Match(text).Groups[2].Value;
                                            }
                                        }
                                        result = null;
                                    }
                                    else
                                    {
                                        result = regex.Match(this.m_c.ToString()).Groups[1].Value;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                this.errmsg = "LoginUnknown\n\n" + ex.Message + "\n" + ex.StackTrace;
                result = null;
            }
            return result;
        }

        // Token: 0x060001A1 RID: 417 RVA: 0x0000BB78 File Offset: 0x00009D78
        public BeanfunClient.QRCodeClass GetQRCodeValue(string skey, bool oldAppQRCode)
        {
            string input = this.DownloadString("https://tw.newlogin.beanfun.com/login/qr_form.aspx?skey=" + skey);
            Regex regex = new Regex("id=\"__VIEWSTATE\" value=\"(.*)\" />");
            if (!regex.IsMatch(input))
            {
                this.errmsg = "LoginNoViewstate";
                return null;
            }
            string value = regex.Match(input).Groups[1].Value;
            regex = new Regex("id=\"__EVENTVALIDATION\" value=\"(.*)\" />");
            if (!regex.IsMatch(input))
            {
                this.errmsg = "LoginNoEventvalidation";
                return null;
            }
            string value2 = regex.Match(input).Groups[1].Value;
            string value3;
            string text;
            if (oldAppQRCode)
            {
                string input2 = this.DownloadString("https://tw.newlogin.beanfun.com/generic_handlers/get_qrcodeData.ashx?skey=" + skey + "&startGame=");
                regex = new Regex("\"strEncryptData\": \"(.*)\"}");
                if (!regex.IsMatch(input2))
                {
                    this.errmsg = "LoginNoQrcodedata";
                    return null;
                }
                value3 = regex.Match(input2).Groups[1].Value;
                text = Uri.UnescapeDataString(value3);
            }
            else
            {
                regex = new Regex("\\$\\(\"#theQrCodeImg\"\\).attr\\(\"src\", \"../(.*)\" \\+ obj.strEncryptData\\);");
                if (!regex.IsMatch(input))
                {
                    this.errmsg = "LoginNoHash";
                    return null;
                }
                value3 = regex.Match(input).Groups[1].Value;
                text = this.getQRCodeStrEncryptData(skey);
                if (text == null || text == "")
                {
                    this.errmsg = "LoginIntResultError";
                    return null;
                }
            }
            return new BeanfunClient.QRCodeClass
            {
                skey = skey,
                viewstate = value,
                eventvalidation = value2,
                value = text,
                bitmapUrl = (oldAppQRCode ? ("http://tw.newlogin.beanfun.com/qrhandler.ashx?u=" + value3) : ("https://tw.newlogin.beanfun.com/" + value3)),
                oldAppQRCode = oldAppQRCode
            };
        }

        // Token: 0x060001A2 RID: 418 RVA: 0x0000BD1C File Offset: 0x00009F1C
        public string getQRCodeStrEncryptData(string skey)
        {
            JObject jobject = JObject.Parse(this.DownloadString("https://tw.newlogin.beanfun.com/generic_handlers/get_qrcodeData.ashx?skey=" + skey));
            if (jobject["intResult"] == null || (int)jobject["intResult"] != 1)
            {
                this.errmsg = "LoginIntResultError";
                return null;
            }
            return (string)jobject["strEncryptData"];
        }

        // Token: 0x060001A3 RID: 419 RVA: 0x0000BD80 File Offset: 0x00009F80
        public BitmapImage getQRCodeImage(BeanfunClient.QRCodeClass qrcodeclass)
        {
            BitmapImage bitmapImage;
            try
            {
                byte[] buffer = base.DownloadData(qrcodeclass.bitmapUrl + (qrcodeclass.oldAppQRCode ? "" : qrcodeclass.value));
                bitmapImage = new BitmapImage();
                bitmapImage.BeginInit();
                bitmapImage.StreamSource = new MemoryStream(buffer);
                bitmapImage.EndInit();
            }
            catch (Exception)
            {
                bitmapImage = null;
            }
            return bitmapImage;
        }

        // Token: 0x060001A4 RID: 420 RVA: 0x0000BDEC File Offset: 0x00009FEC
        private string a(BeanfunClient.QRCodeClass A_0)
        {
            string result;
            try
            {
                string skey = A_0.skey;
                base.Headers.Set("Referer", "https://tw.newlogin.beanfun.com/login/qr_form.aspx?skey=" + skey);
                this.m_f = false;
                byte[] bytes = base.DownloadData("https://tw.newlogin.beanfun.com/login/qr_step2.aspx?skey=" + skey);
                this.m_f = true;
                string @string = Encoding.UTF8.GetString(bytes);
                Regex regex = new Regex("akey=(.*)&authkey");
                if (!regex.IsMatch(@string))
                {
                    this.errmsg = "AKeyParseFailed";
                    result = null;
                }
                else
                {
                    string value = regex.Match(@string).Groups[1].Value;
                    regex = new Regex("authkey=(.*)&");
                    if (!regex.IsMatch(@string))
                    {
                        this.errmsg = "authkeyParseFailed";
                        result = null;
                    }
                    else
                    {
                        string value2 = regex.Match(@string).Groups[1].Value;
                        this.DownloadString(string.Concat(new string[]
                        {
                            "https://tw.newlogin.beanfun.com/login/final_step.aspx?akey=",
                            value,
                            "&authkey=",
                            value2,
                            "&bfapp=1"
                        }));
                        result = value;
                    }
                }
            }
            catch (Exception ex)
            {
                this.errmsg = "LoginUnknown\n\n" + ex.Message + "\n" + ex.StackTrace;
                result = null;
            }
            return result;
        }

        // Token: 0x060001A5 RID: 421 RVA: 0x0000BF48 File Offset: 0x0000A148
        public int QRCodeCheckLoginStatus(BeanfunClient.QRCodeClass qrcodeclass)
        {
            try
            {
                string skey = qrcodeclass.skey;
                base.Headers.Set("Referer", "https://tw.newlogin.beanfun.com/login/qr_form.aspx?skey=" + skey);
                NameValueCollection nameValueCollection = new NameValueCollection();
                nameValueCollection.Add(qrcodeclass.oldAppQRCode ? "data" : "status", qrcodeclass.value);
                string text = this.UploadString(qrcodeclass.oldAppQRCode ? "https://tw.bfapp.beanfun.com/api/Check/CheckLoginStatus" : "https://tw.newlogin.beanfun.com/generic_handlers/CheckLoginStatus.ashx", nameValueCollection);
                JObject jobject;
                try
                {
                    jobject = JObject.Parse(text);
                }
                catch
                {
                    this.errmsg = "LoginJsonParseFailed";
                    return -1;
                }
                string value = (string)jobject["ResultMessage"];
                Console.WriteLine(value);
                if (value == "Failed")
                {
                    return 0;
                }
                if (value == "Token Expired")
                {
                    return -2;
                }
                if (value == "Success")
                {
                    return 1;
                }
                this.errmsg = text;
                return -1;
            }
            catch (Exception ex)
            {
                this.errmsg = "Network Error on QRCode checking login status\n\n" + ex.Message + "\n" + ex.StackTrace;
            }
            return -1;
        }

        // Token: 0x060001A6 RID: 422 RVA: 0x0000C07C File Offset: 0x0000A27C
        public JObject CheckIsRegisteDevice(string service_code = "610074", string service_region = "T9")
        {
            JObject jobject = JObject.Parse(this.UploadString("https://tw.newlogin.beanfun.com/login/bfAPPAutoLogin.ashx", new NameValueCollection
            {
                {
                    "LT",
                    this.m_g
                }
            }));
            if (jobject == null || jobject["IntResult"] == null || jobject["StrReslut"] == null)
            {
                return null;
            }
            if ((string)jobject["IntResult"] == "2")
            {
                this.DownloadString("https://tw.newlogin.beanfun.com/login/" + (string)jobject["StrReslut"]);
                Regex regex = new Regex("akey=(.*)");
                if (!regex.IsMatch((string)jobject["StrReslut"]))
                {
                    this.errmsg = "AKeyParseFailed";
                    return null;
                }
                string value = regex.Match((string)jobject["StrReslut"]).Groups[1].Value;
                this.a(value, service_code, service_region);
            }
            return jobject;
        }

        // Token: 0x060001A7 RID: 423 RVA: 0x0000C174 File Offset: 0x0000A374
        public string GetSessionkey()
        {
            if (App.LoginRegion == "TW")
            {
                string text = this.DownloadString("https://tw.beanfun.com/beanfun_block/bflogin/default.aspx?service=999999_T0");
                text = this.m_c.ToString();
                if (text == null)
                {
                    this.errmsg = "LoginNoResponse";
                    return null;
                }
                Regex regex = new Regex("skey=(.*)&display");
                if (!regex.IsMatch(text))
                {
                    this.errmsg = "LoginNoSkey";
                    return null;
                }
                return regex.Match(text).Groups[1].Value;
            }
            else
            {
                string text2 = this.DownloadString("http://hk.beanfun.com/beanfun_block/login/index.aspx?service=999999_T0");
                if (text2 == null)
                {
                    this.errmsg = "LoginNoResponse";
                    return null;
                }
                Regex regex2 = new Regex("otp1 = \"(.*)\";");
                if (!regex2.IsMatch(text2))
                {
                    this.errmsg = "LoginNoOTP1";
                    return null;
                }
                return regex2.Match(text2).Groups[1].Value;
            }
        }

        // Token: 0x060001A8 RID: 424 RVA: 0x0000C248 File Offset: 0x0000A448
        public void Login(string id, string pass, int loginMethod, BeanfunClient.QRCodeClass qrcodeClass = null, string service_code = "610074", string service_region = "T9")
        {
            this.m_d = null;
            this.m_h = null;
            try
            {
                if (loginMethod == 1)
                {
                    this.m_h = qrcodeClass.skey;
                }
                else
                {
                    if (App.LoginRegion == "HK")
                    {
                        if (this.m_a == null)
                        {
                            try
                            {
                                this.m_a = new BFServiceX();
                            }
                            catch
                            {
                                this.errmsg = "BFServiceXNotFound";
                                return;
                            }
                        }
                        this.m_a.Initialize2();
                    }
                    this.m_h = this.GetSessionkey();
                }
                string a_;
                if (loginMethod != 0)
                {
                    if (loginMethod != 1)
                    {
                        this.errmsg = "LoginNoMethod";
                        return;
                    }
                    a_ = this.a(qrcodeClass);
                }
                else if (App.LoginRegion == "TW")
                {
                    a_ = this.b(id, pass, this.m_h);
                }
                else
                {
                    a_ = this.c(id, pass, this.m_h);
                }
                this.a(a_, service_code, service_region);
            }
            catch (Exception ex)
            {
                if (ex is WebException)
                {
                    this.errmsg = "登陆失败，请检查官方网站或者更换加速器" + ex.Message;
                }
                else
                {
                    this.errmsg = "LoginUnknown\n\n" + ex.Message + "\n" + ex.StackTrace;
                }
            }
        }

        // Token: 0x060001A9 RID: 425 RVA: 0x0000C388 File Offset: 0x0000A588
        private void a(string A_0, string A_1 = "610074", string A_2 = "T9")
        {
            if (this.m_h == null || A_0 == null)
            {
                return;
            }
            if (App.LoginRegion == "TW")
            {
                this.UploadString("https://tw.beanfun.com/beanfun_block/bflogin/return.aspx", new NameValueCollection
                {
                    {
                        "SessionKey",
                        this.m_h
                    },
                    {
                        "AuthKey",
                        A_0
                    },
                    {
                        "ServiceCode",
                        ""
                    },
                    {
                        "ServiceRegion",
                        ""
                    },
                    {
                        "ServiceAccountSN",
                        "0"
                    }
                });
                this.DownloadString("https://tw.beanfun.com/" + base.ResponseHeaders["Location"]);
                this.m_d = this.a("bfWebToken");
                if (this.m_d == "")
                {
                    this.errmsg = "LoginNoWebtoken";
                    return;
                }
                this.GetAccounts(A_1, A_2, false);
            }
            else
            {
                if (!this.DownloadString(string.Concat(new string[]
                {
                    "http://hk.beanfun.com/beanfun_block/auth.aspx?channel=game_zone&page_and_query=game_start.aspx%3Fservice_code_and_region%3D",
                    A_1,
                    "_",
                    A_2,
                    "&token=",
                    this.m_a.Token
                })).Contains("document.location = \"http://hk.beanfun.com/beanfun_block/game_zone/game_server_account_list.aspx"))
                {
                    this.errmsg = "LoginAuthErr";
                    return;
                }
                this.GetAccounts_HK(A_1, A_2, false);
            }
            if (this.errmsg != null)
            {
                return;
            }
            this.remainPoint = this.getRemainPoint();
            this.errmsg = null;
        }

        // Token: 0x060001AA RID: 426 RVA: 0x0000C4EC File Offset: 0x0000A6EC
        public void Logout()
        {
            if (App.LoginRegion == "TW")
            {
                this.DownloadString("https://tw.beanfun.com/generic_handlers/remove_bflogin_session.ashx");
                this.UploadString("https://tw.newlogin.beanfun.com/generic_handlers/erase_token.ashx", new NameValueCollection
                {
                    {
                        "web_token",
                        "1"
                    }
                });
                return;
            }
            this.DownloadString("http://hk.beanfun.com/beanfun_block/generic_handlers/remove_login_session.ashx");
            this.DownloadString("http://hk.beanfun.com/beanfun_web_ap/remove_login_session.ashx");
            if (this.m_a != null)
            {
                this.DownloadString("http://hk.beanfun.com/beanfun_block/generic_handlers/erase_token.ashx?token=" + this.m_a.Token);
            }
        }

        // Token: 0x060001AB RID: 427 RVA: 0x0000C578 File Offset: 0x0000A778
        public string GetOTP(BeanfunClient.ServiceAccount acc, string service_code = "610074", string service_region = "T9")
        {
            string result;
            try
            {
                string text;
                if (App.LoginRegion == "TW")
                {
                    text = this.DownloadString(string.Concat(new string[]
                    {
                        "https://tw.beanfun.com/beanfun_block/game_zone/game_start_step2.aspx?service_code=",
                        service_code,
                        "&service_region=",
                        service_region,
                        "&sotp=",
                        acc.ssn,
                        "&dt=",
                        this.a(2)
                    }));
                    Regex regex = new Regex("GetResultByLongPolling&key=(.*)\"");
                    if (!regex.IsMatch(text))
                    {
                        this.errmsg = "OTPNoLongPollingKey:" + text;
                        return null;
                    }
                    string value = regex.Match(text).Groups[1].Value;
                    if (acc.screatetime == null)
                    {
                        regex = new Regex("ServiceAccountCreateTime: \"([^\"]+)\"");
                        if (!regex.IsMatch(text))
                        {
                            this.errmsg = "OTPNoCreateTime";
                            return null;
                        }
                        acc.screatetime = regex.Match(text).Groups[1].Value;
                    }
                    text = this.DownloadString("https://tw.newlogin.beanfun.com/generic_handlers/get_cookies.ashx");
                    regex = new Regex("var m_strSecretCode = '(.*)';");
                    if (!regex.IsMatch(text))
                    {
                        this.errmsg = "OTPNoSecretCode";
                        return null;
                    }
                    string value2 = regex.Match(text).Groups[1].Value;
                    NameValueCollection nameValueCollection = new NameValueCollection();
                    nameValueCollection.Add("service_code", service_code);
                    nameValueCollection.Add("service_region", service_region);
                    nameValueCollection.Add("service_account_id", acc.sid);
                    nameValueCollection.Add("sotp", acc.ssn);
                    nameValueCollection.Add("service_account_display_name", acc.sname);
                    nameValueCollection.Add("service_account_create_time", acc.screatetime);
                    ServicePointManager.Expect100Continue = false;
                    this.UploadString("https://tw.beanfun.com/beanfun_block/generic_handlers/record_service_start.ashx", nameValueCollection);
                    text = this.DownloadString("https://tw.beanfun.com/generic_handlers/get_result.ashx?meth=GetResultByLongPolling&key=" + value + "&_=" + this.a(0));
                    text = this.DownloadString(string.Concat(new string[]
                    {
                        "https://tw.beanfun.com/beanfun_block/generic_handlers/get_webstart_otp.ashx?SN=",
                        value,
                        "&WebToken=",
                        this.m_d,
                        "&SecretCode=",
                        value2,
                        "&ppppp=1F552AEAFF976018F942B13690C990F60ED01510DDF89165F1658CCE7BC21DBA&ServiceCode=",
                        service_code,
                        "&ServiceRegion=",
                        service_region,
                        "&ServiceAccount=",
                        acc.sid,
                        "&CreateTime=",
                        acc.screatetime.Replace(" ", "%20"),
                        "&d=",
                        Environment.TickCount.ToString()
                    }));
                }
                else
                {
                    text = this.DownloadString(string.Concat(new string[]
                    {
                        "http://hk.beanfun.com/beanfun_block/auth.aspx?channel=game_zone&page_and_query=game_start_step2.aspx%3Fservice_code%3D",
                        service_code,
                        "%26service_region%3D",
                        service_region,
                        "%26service_account_sn%3D",
                        acc.ssn,
                        "&token=",
                        this.m_a.Token
                    }));
                    if (text == "")
                    {
                        this.errmsg = "OTPNoResponse";
                        return null;
                    }
                    Regex regex2 = new Regex("<span id=\"lblLoginFailMsg\">(.*)</span>");
                    if (regex2.IsMatch(text))
                    {
                        this.errmsg = "OTPNoLongPollingKey:" + regex2.Match(text).Groups[1].Value;
                        return null;
                    }
                    regex2 = new Regex("var MyAccountData = (.*);");
                    if (!regex2.IsMatch(text))
                    {
                        this.errmsg = "OTPNoMyAccountData";
                        return null;
                    }
                    JObject jobject = JObject.Parse(regex2.Match(text).Groups[1].Value);
                    acc.sname = (string)jobject["ServiceAccountDisplayName"];
                    acc.screatetime = (string)jobject["ServiceAccountCreateTime"];
                    NameValueCollection nameValueCollection2 = new NameValueCollection();
                    nameValueCollection2.Add("service_code", service_code);
                    nameValueCollection2.Add("service_region", service_region);
                    nameValueCollection2.Add("service_account_id", acc.sid);
                    nameValueCollection2.Add("service_sotp", acc.ssn);
                    nameValueCollection2.Add("service_display_name", acc.sname);
                    nameValueCollection2.Add("service_create_time", acc.screatetime);
                    ServicePointManager.Expect100Continue = false;
                    this.UploadString("http://hk.beanfun.com/beanfun_block/generic_handlers/record_service_start.ashx", nameValueCollection2);
                    text = this.DownloadString(string.Concat(new string[]
                    {
                        "http://hk.beanfun.com/beanfun_block/generic_handlers/get_otp.ashx?ppppp=&token=",
                        this.m_a.Token,
                        "&account_service_code=",
                        service_code,
                        "&account_service_region=",
                        service_region,
                        "&service_account_id=",
                        acc.sid,
                        "&create_time=",
                        acc.screatetime.Replace(" ", "%20"),
                        "&d=",
                        Environment.TickCount.ToString()
                    }));
                }
                if (text == null || text == "")
                {
                    this.errmsg = "OTPNoResponse";
                    result = null;
                }
                else
                {
                    string[] array = text.Split(new char[]
                    {
                        ';'
                    });
                    if (array.Length < 2)
                    {
                        this.errmsg = "OTPNoResponse";
                        result = null;
                    }
                    else
                    {
                        text = array[1];
                        if (array[0] != "1")
                        {
                            this.errmsg = "密碼取得失败。\r\n" + text;
                            result = null;
                        }
                        else
                        {
                            string a_ = text.Substring(0, 8);
                            string text2 = global::f.a(text.Substring(8), a_);
                            if (text2 != null)
                            {
                                text2 = text2.Trim(new char[1]);
                                this.errmsg = null;
                            }
                            else
                            {
                                this.errmsg = "DecryptOTPError";
                            }
                            result = text2;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                this.errmsg = "密碼取得失败。\n\n" + ex.Message + "\n" + ex.StackTrace;
                result = null;
            }
            return result;
        }

        // Token: 0x060001AC RID: 428 RVA: 0x0000CB4C File Offset: 0x0000AD4C
        public string getVerifyPageInfo()
        {
            string result;
            try
            {
                result = this.DownloadString("https://tw.newlogin.beanfun.com/LoginCheck/AdvanceCheck.aspx");
            }
            catch (Exception ex)
            {
                this.errmsg = "VerifyUnknown\n\n" + ex.Message + "\n" + ex.StackTrace;
                result = null;
            }
            return result;
        }

        // Token: 0x060001AD RID: 429 RVA: 0x0000CBA0 File Offset: 0x0000ADA0
        public BitmapImage getVerifyCaptcha(string samplecaptcha)
        {
            BitmapImage bitmapImage;
            try
            {
                byte[] buffer = base.DownloadData("https://tw.newlogin.beanfun.com/LoginCheck/BotDetectCaptcha.ashx?get=image&c=c_logincheck_advancecheck_samplecaptcha&t=" + samplecaptcha);
                bitmapImage = new BitmapImage();
                bitmapImage.BeginInit();
                bitmapImage.StreamSource = new MemoryStream(buffer);
                bitmapImage.EndInit();
            }
            catch (Exception)
            {
                bitmapImage = null;
            }
            return bitmapImage;
        }

        // Token: 0x060001AE RID: 430 RVA: 0x0000CBF8 File Offset: 0x0000ADF8
        public string verify(string viewstate, string eventvalidation, string samplecaptcha, string verifyCode, string captchaCode)
        {
            string result;
            try
            {
                result = this.UploadString("https://tw.newlogin.beanfun.com/LoginCheck/AdvanceCheck.aspx", new NameValueCollection
                {
                    {
                        "__VIEWSTATE",
                        viewstate
                    },
                    {
                        "__EVENTVALIDATION",
                        eventvalidation
                    },
                    {
                        "txtVerify",
                        verifyCode
                    },
                    {
                        "CodeTextBox",
                        captchaCode
                    },
                    {
                        "imgbtnSubmit.x",
                        "19"
                    },
                    {
                        "imgbtnSubmit.y",
                        "23"
                    },
                    {
                        "LBD_VCID_c_logincheck_advancecheck_samplecaptcha",
                        samplecaptcha
                    }
                });
            }
            catch (Exception ex)
            {
                this.errmsg = "VerifyUnknown\n\n" + ex.Message + "\n" + ex.StackTrace;
                result = null;
            }
            return result;
        }

        // Token: 0x0400010F RID: 271
        //public GameServerAccountListApp gameServAccListApp;

        private BFServiceX m_a;

        private CookieContainer m_b;

        private Uri m_c;

        public string errmsg;

        private string m_d;

        private string m_e;

        public List<BeanfunClient.ServiceAccount> accountList;

        public int remainPoint;

        public string accountAmountLimitNotice;

        private bool m_f;

        private const string g = "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36";

        private string m_g;

        private string m_h;

        private int m_i;

        // Token: 0x02000040 RID: 64
        public class ServiceAccount
        {
            // Token: 0x17000019 RID: 25
            // (get) Token: 0x060001AF RID: 431 RVA: 0x0000CCB0 File Offset: 0x0000AEB0
            // (set) Token: 0x060001B0 RID: 432 RVA: 0x0000CCB8 File Offset: 0x0000AEB8
            public bool isEnable
            {
                [CompilerGenerated]
                get
                {
                    return this.a;
                }
                [CompilerGenerated]
                set
                {
                    this.a = value;
                }
            }

            // Token: 0x1700001A RID: 26
            // (get) Token: 0x060001B1 RID: 433 RVA: 0x0000CCC1 File Offset: 0x0000AEC1
            // (set) Token: 0x060001B2 RID: 434 RVA: 0x0000CCC9 File Offset: 0x0000AEC9
            public bool visible
            {
                [CompilerGenerated]
                get
                {
                    return this.b;
                }
                [CompilerGenerated]
                set
                {
                    this.b = value;
                }
            }

            // Token: 0x1700001B RID: 27
            // (get) Token: 0x060001B3 RID: 435 RVA: 0x0000CCD2 File Offset: 0x0000AED2
            // (set) Token: 0x060001B4 RID: 436 RVA: 0x0000CCDA File Offset: 0x0000AEDA
            public bool isinherited
            {
                [CompilerGenerated]
                get
                {
                    return this.c;
                }
                [CompilerGenerated]
                set
                {
                    this.c = value;
                }
            }

            // Token: 0x1700001C RID: 28
            // (get) Token: 0x060001B5 RID: 437 RVA: 0x0000CCE3 File Offset: 0x0000AEE3
            // (set) Token: 0x060001B6 RID: 438 RVA: 0x0000CCEB File Offset: 0x0000AEEB
            public string sid
            {
                [CompilerGenerated]
                get
                {
                    return this.d;
                }
                [CompilerGenerated]
                set
                {
                    this.d = value;
                }
            }

            // Token: 0x1700001D RID: 29
            // (get) Token: 0x060001B7 RID: 439 RVA: 0x0000CCF4 File Offset: 0x0000AEF4
            // (set) Token: 0x060001B8 RID: 440 RVA: 0x0000CCFC File Offset: 0x0000AEFC
            public string ssn
            {
                [CompilerGenerated]
                get
                {
                    return this.e;
                }
                [CompilerGenerated]
                set
                {
                    this.e = value;
                }
            }

            // Token: 0x1700001E RID: 30
            // (get) Token: 0x060001B9 RID: 441 RVA: 0x0000CD05 File Offset: 0x0000AF05
            // (set) Token: 0x060001BA RID: 442 RVA: 0x0000CD0D File Offset: 0x0000AF0D
            public string sname
            {
                [CompilerGenerated]
                get
                {
                    return this.f;
                }
                [CompilerGenerated]
                set
                {
                    this.f = value;
                }
            }

            // Token: 0x1700001F RID: 31
            // (get) Token: 0x060001BB RID: 443 RVA: 0x0000CD16 File Offset: 0x0000AF16
            // (set) Token: 0x060001BC RID: 444 RVA: 0x0000CD1E File Offset: 0x0000AF1E
            public string screatetime
            {
                [CompilerGenerated]
                get
                {
                    return this.g;
                }
                [CompilerGenerated]
                set
                {
                    this.g = value;
                }
            }

            // Token: 0x17000020 RID: 32
            // (get) Token: 0x060001BD RID: 445 RVA: 0x0000CD27 File Offset: 0x0000AF27
            // (set) Token: 0x060001BE RID: 446 RVA: 0x0000CD2F File Offset: 0x0000AF2F
            public string slastusedtime
            {
                [CompilerGenerated]
                get
                {
                    return this.h;
                }
                [CompilerGenerated]
                set
                {
                    this.h = value;
                }
            }

            // Token: 0x17000021 RID: 33
            // (get) Token: 0x060001BF RID: 447 RVA: 0x0000CD38 File Offset: 0x0000AF38
            // (set) Token: 0x060001C0 RID: 448 RVA: 0x0000CD40 File Offset: 0x0000AF40
            public string sauthtype
            {
                [CompilerGenerated]
                get
                {
                    return this.i;
                }
                [CompilerGenerated]
                set
                {
                    this.i = value;
                }
            }

            // Token: 0x060001C1 RID: 449 RVA: 0x0000CD4C File Offset: 0x0000AF4C
            public ServiceAccount(bool isEnable, string sid, string ssn, string sname, string screatetime)
            {
                this.isEnable = isEnable;
                this.visible = true;
                this.isinherited = false;
                this.sid = sid;
                this.ssn = ssn;
                this.sname = sname;
                this.screatetime = screatetime;
                this.slastusedtime = null;
                this.sauthtype = null;
            }

            // Token: 0x060001C2 RID: 450 RVA: 0x0000CDA0 File Offset: 0x0000AFA0
            public ServiceAccount(bool isEnable, bool visible, bool isinherited, string sid, string ssn, string sname, string screatetime, string slastusedtime, string sauthtype)
            {
                this.isEnable = isEnable;
                this.visible = visible;
                this.isinherited = isinherited;
                this.sid = sid;
                this.ssn = ssn;
                this.sname = sname;
                this.screatetime = screatetime;
                this.slastusedtime = slastusedtime;
                this.sauthtype = sauthtype;
            }

            // Token: 0x0400011C RID: 284
            [CompilerGenerated]
            private bool a;

            // Token: 0x0400011D RID: 285
            [CompilerGenerated]
            private bool b;

            // Token: 0x0400011E RID: 286
            [CompilerGenerated]
            private bool c;

            // Token: 0x0400011F RID: 287
            [CompilerGenerated]
            private string d;

            // Token: 0x04000120 RID: 288
            [CompilerGenerated]
            private string e;

            // Token: 0x04000121 RID: 289
            [CompilerGenerated]
            private string f;

            // Token: 0x04000122 RID: 290
            [CompilerGenerated]
            private string g;

            // Token: 0x04000123 RID: 291
            [CompilerGenerated]
            private string h;

            // Token: 0x04000124 RID: 292
            [CompilerGenerated]
            private string i;
        }

        // Token: 0x02000041 RID: 65
        public class QRCodeClass
        {
            // Token: 0x060001C3 RID: 451 RVA: 0x0000CDF8 File Offset: 0x0000AFF8
            public QRCodeClass()
            {
            }

            // Token: 0x04000125 RID: 293
            public string skey;

            // Token: 0x04000126 RID: 294
            public string value;

            // Token: 0x04000127 RID: 295
            public string viewstate;

            // Token: 0x04000128 RID: 296
            public string eventvalidation;

            // Token: 0x04000129 RID: 297
            public string bitmapUrl;

            // Token: 0x0400012A RID: 298
            public bool oldAppQRCode;
        }

        // Token: 0x02000042 RID: 66
        //[CompilerGenerated]
        //[Serializable]
        private sealed class C
        {
            // Token: 0x060001C4 RID: 452 RVA: 0x0000CE00 File Offset: 0x0000B000
            // Note: this type is marked as 'beforefieldinit'.
            static C()
            {
            }

            // Token: 0x060001C5 RID: 453 RVA: 0x0000CE0C File Offset: 0x0000B00C
            public C()
            {
            }

            // Token: 0x060001C6 RID: 454 RVA: 0x0000CE14 File Offset: 0x0000B014
            internal int a(BeanfunClient.ServiceAccount A_0, BeanfunClient.ServiceAccount A_1)
            {
                return A_0.ssn.CompareTo(A_1.ssn);
            }

            // Token: 0x060001C7 RID: 455 RVA: 0x0000CE27 File Offset: 0x0000B027
            internal int b(BeanfunClient.ServiceAccount A_0, BeanfunClient.ServiceAccount A_1)
            {
                return A_0.ssn.CompareTo(A_1.ssn);
            }

            // Token: 0x0400012B RID: 299
            public static readonly BeanfunClient.C m_c = new BeanfunClient.C();

            // Token: 0x0400012C RID: 300
            public static Comparison<BeanfunClient.ServiceAccount> m_a;

            // Token: 0x0400012D RID: 301
            public static Comparison<BeanfunClient.ServiceAccount> m_b;

        }
    }
}
