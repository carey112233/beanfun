﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media.Imaging;
using SourceChord.FluentWPF;

namespace Beanfun
{
	// Token: 0x0200001F RID: 31
	public partial class CaptchaWnd : Window, IComponentConnector
	{
		// Token: 0x17000013 RID: 19
		// (get) Token: 0x060000A9 RID: 169 RVA: 0x00004534 File Offset: 0x00002734
		public string Captcha
		{
			get
			{
				return this.m_c.Text;
			}
		}

		// Token: 0x060000AA RID: 170 RVA: 0x00004541 File Offset: 0x00002741
		public CaptchaWnd(BeanfunClient client, string samplecaptcha)
		{
			this.InitializeComponent();
			if (!App.IsWin10)
			{
				AcrylicWindow.SetTintOpacity(this, 1.0);
			}
			this.m_a = samplecaptcha;
			this.m_b = client;
			this.b(null, null);
		}

		// Token: 0x060000AB RID: 171 RVA: 0x0000457B File Offset: 0x0000277B
		private void a(object A_0, MouseButtonEventArgs A_1)
		{
			base.DragMove();
		}

		// Token: 0x060000AC RID: 172 RVA: 0x00004584 File Offset: 0x00002784
		private void b(object A_0, RoutedEventArgs A_1)
		{
			BitmapImage bitmapImage;
			try
			{
				byte[] buffer = this.m_b.DownloadData("https://tw.newlogin.beanfun.com/login/BotDetectCaptcha.ashx?get=image&c=c_login_idpass_form_samplecaptcha&t=" + this.m_a);
				bitmapImage = new BitmapImage();
				bitmapImage.BeginInit();
				bitmapImage.StreamSource = new MemoryStream(buffer);
				bitmapImage.EndInit();
			}
			catch (Exception)
			{
				MessageBox.Show("载入验证码失败");
				return;
			}
			this.d.Source = bitmapImage;
		}

		// Token: 0x060000AD RID: 173 RVA: 0x000045F8 File Offset: 0x000027F8
		private void a(object A_0, RoutedEventArgs A_1)
		{
			base.Close();
		}

		// Token: 0x060000AE RID: 174 RVA: 0x00004600 File Offset: 0x00002800

		//public void InitializeComponent()
		//{
		//	if (this.m_e)
		//	{
		//		return;
		//	}
		//	this.m_e = true;
		//	Uri resourceLocator = new Uri("/Beanfun;component/windows/captchawnd.xaml", UriKind.Relative);
		//	Application.LoadComponent(this, resourceLocator);
		//}

		// Token: 0x060000AF RID: 175 RVA: 0x00004630 File Offset: 0x00002830


		// Token: 0x0400006B RID: 107
		private string m_a;

		// Token: 0x0400006C RID: 108
		private BeanfunClient m_b;

		// Token: 0x0400006D RID: 109
		internal TextBox m_c;

		// Token: 0x0400006E RID: 110
		internal Image m_d;

		// Token: 0x0400006F RID: 111
		private bool m_e;
	}
}
