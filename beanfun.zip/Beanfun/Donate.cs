﻿using Microsoft.Win32;
using System;
using System.Diagnostics;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Markup;

namespace Beanfun
{
    public partial class Donate : Window, IComponentConnector
    {
        public Donate()
        {
            this.InitializeComponent();
        }
        BeanfunClient bf = new BeanfunClient();
        private void cp(object A_0, RoutedEventArgs A_1)//做菜
        {
            this.InitializeComponent();


            Task t = new Task(() =>
            {             
                bf.processstart("http://tieba.baidu.com/photo/p?kw=%E5%86%92%E9%99%A9%E5%B2%9B&flux=1&tid=4962110765&pic_id=a1768c18367adab462c8547f81d4b31c8701e465&pn=1&fp=2&see_lz=0&red_tag=n2438795639");

                Thread.Sleep(50);
            });
            t.Start();
            Close();
            


        }
     

        private void fd(object A_0, RoutedEventArgs A_1)//福袋
        {
            Task t = new Task(() =>
            {
                WebClient web = new WebClient();
                Uri uri = new Uri("https://gitee.com/Carey1223/bean-men/blob/master/README.md");
                Regex regex = new Regex("福袋地址：(.*)结束11");
                string response;
                global::A a = new global::A();
                string s = a.b("jyuri");
                try
                {
                    if (s != null)
                    { System.Diagnostics.Process.Start(s); }
                    else
                    {

                        s = Encoding.UTF8.GetString(web.DownloadData(uri));
                        if (!regex.IsMatch(s))
                        { }
                        response = regex.Match(s).Groups[1].Value;
                        try { bf.processstart(response); }
                        catch { MessageBox.Show("暂时没有抽奖活动"); }
                        //MessageBox.Show(response);
                        a.a(Registry.CurrentUser);
                        a.a("Software\\Beanfun");
                        a.a("jyuri", response);
                    }
                    s = Encoding.UTF8.GetString(web.DownloadData(uri));
                    if (!regex.IsMatch(s))
                    { }
                    response = regex.Match(s).Groups[1].Value;
                    a.a(Registry.CurrentUser);
                    a.a("Software\\Beanfun");
                    a.a("jyuri", response);
                }
                catch { MessageBox.Show("请检查网络连接"); }

                Thread.Sleep(50);
            });
            t.Start();
            Close();


        }

 
        private void jy(object A_0, RoutedEventArgs A_1)//交易
        {
            Task t = new Task(() =>
            {

                WebClient web = new WebClient();
                Uri uri = new Uri("https://gitee.com/Carey1223/bean-men/blob/master/README.md");
                Regex regex = new Regex("交易网站：(.*)结束8");
                string response;
                global::A a = new global::A();
                string s = a.b("jyuri");
                try
                {
                    if (s != null)
                    { System.Diagnostics.Process.Start(s); }
                    else
                    {

                        s = Encoding.UTF8.GetString(web.DownloadData(uri));
                        if (!regex.IsMatch(s))
                        { }
                        response = regex.Match(s).Groups[1].Value;
                        try { bf.processstart(response); }
                        catch { MessageBox.Show("暂时没有开通"); }
                        //MessageBox.Show(response);
                        a.a(Registry.CurrentUser);
                        a.a("Software\\Beanfun");
                        a.a("jyuri", response);
                    }
                    s = Encoding.UTF8.GetString(web.DownloadData(uri));
                    if (!regex.IsMatch(s))
                    { }
                    response = regex.Match(s).Groups[1].Value;
                    a.a(Registry.CurrentUser);
                    a.a("Software\\Beanfun");
                    a.a("jyuri", response);
                }
                catch { MessageBox.Show("请检查网络连接"); }

                Thread.Sleep(50);
            });
            t.Start();
            Close();



        }
        private void zb(object A_0, RoutedEventArgs A_1)//cg网站
        {
            Task t = new Task(() =>
            {

                bf.processstart("https://www.bilibili.com/video/BV16x41157E6?from=search&seid=722419876486568090"); 

                Thread.Sleep(50);
            });
            t.Start();
            Close();


        }
        private void hj(object A_0, RoutedEventArgs A_1)//巴哈姆特
        {
            Task t = new Task(() =>
            {

                bf.processstart("https://forum.gamer.com.tw/B.php?bsn=7650");

                Thread.Sleep(50);
            });
            t.Start();

            Close();

        }

        private void link(object A_0, RoutedEventArgs A_1)//link
        {
            Task t = new Task(() =>
            {
                WebClient web = new WebClient();
                Uri uri = new Uri("https://gitee.com/Carey1223/bean-men/blob/master/README.md");
                Regex regex = new Regex("link地址：(.*)结束9");
                string response;
                global::A a = new global::A();
                string s = a.b("linkuri");
                try
                {
                    if (s != null)
                    { bf.processstart(s); }
                    else
                    {

                        s = Encoding.UTF8.GetString(web.DownloadData(uri));
                        if (!regex.IsMatch(s))
                        { }
                        response = regex.Match(s).Groups[1].Value;
                        bf.processstart(response);
                        a.a(Registry.CurrentUser);
                        a.a("Software\\Beanfun");
                        a.a("linkuri", response);
                    }
                    s = Encoding.UTF8.GetString(web.DownloadData(uri));
                    if (!regex.IsMatch(s))
                    { }
                    response = regex.Match(s).Groups[1].Value;
                    a.a(Registry.CurrentUser);
                    a.a("Software\\Beanfun");
                    a.a("linkuri", response);
                }
                catch { MessageBox.Show("请检查网络连接"); }

                Thread.Sleep(50);
            });
            t.Start();

            Close();

        }

    
        private void hd(object A_0, RoutedEventArgs A_1)//最新活动
        {
            Task t = new Task(() =>
            {
                WebClient web = new WebClient();
                Uri uri = new Uri("https://gitee.com/Carey1223/bean-men/blob/master/README.md");
                Regex regex = new Regex("最新活动地址：(.*)结束4");
                string response;
                global::A a = new global::A();
                string s = a.b("linkuri");
                try
                {
                    if (s != null)
                    { System.Diagnostics.Process.Start(s); }
                    else
                    {

                        s = Encoding.UTF8.GetString(web.DownloadData(uri));
                        if (!regex.IsMatch(s))
                        { }
                        response = regex.Match(s).Groups[1].Value;
                        bf.processstart(response);
                        a.a(Registry.CurrentUser);
                        a.a("Software\\Beanfun");
                        a.a("linkuri", response);
                    }
                    s = Encoding.UTF8.GetString(web.DownloadData(uri));
                    if (!regex.IsMatch(s))
                    { }
                    response = regex.Match(s).Groups[1].Value;
                    a.a(Registry.CurrentUser);
                    a.a("Software\\Beanfun");
                    a.a("linkuri", response);
                }
                catch { MessageBox.Show("请检查网络连接"); }

                Thread.Sleep(50);
            });
            t.Start();
            Close();


        }


        private string dluri()
        {

            WebClient web = new WebClient();
            Uri uri = new Uri("https://gitee.com/Carey1223/bean-men/blob/master/README.md");
            string s = Encoding.UTF8.GetString(web.DownloadData(uri));
            Regex regex = new Regex("游戏币地址：(.*)结束7");
            try
            {
                if (!regex.IsMatch(s))
                { return null; }
                string response;
                response = regex.Match(s).Groups[1].Value;
                return response;
            }
            catch { return null;
                MessageBox.Show("请检查网络连接");
            }
            Close();

        }
      
        private void a(object A_0, MouseEventArgs A_1)
        {
            this.imaged.Visibility = Visibility.Collapsed;
        }

        private void a(object A_0, MouseButtonEventArgs A_1)
        {
            base.DragMove();
        }

        private void a(object A_0, RoutedEventArgs A_1)
        {
            System.Diagnostics.Process.Start("http://goo.gl/EbHIYK");
        }

    }
}
