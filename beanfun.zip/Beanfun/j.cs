﻿using System;

// Token: 0x02000016 RID: 22
internal enum j
{
	// Token: 0x0400004F RID: 79
	a,
	// Token: 0x04000050 RID: 80
	b,
	// Token: 0x04000051 RID: 81
	c
}
