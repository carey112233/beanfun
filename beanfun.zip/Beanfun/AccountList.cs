﻿using Microsoft.Win32;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

namespace Beanfun
{
	
	public partial class AccountList : Page, IComponentConnector
	{
		
		public AccountList()
		{
			this.InitializeComponent();

			this.imageab.IsChecked = new bool?(bool.Parse(global::g.a("autoPaste", "false")));
		}
		BeanfunClient bf = new BeanfunClient();

		private void q(object A_0, RoutedEventArgs A_1)
		{

			if (MessageBox.Show("即将退出，是否要继续？", "退出", MessageBoxButton.YesNo) == MessageBoxResult.No)
			{
				return;
			}
			if (App.MainWnd.bfClient != null)
			{
				App.MainWnd.bfClient.Logout();
			}
			if (App.MainWnd.loginPage.imagec.SelectedIndex == 1)
			{
				App.MainWnd.ddlAuthType_SelectionChanged(null, null);
			}
			App.MainWnd.o.Content = App.MainWnd.loginPage;
		}
		private void js(object A_0, RoutedEventArgs A_1)
		{

			WebClient web = new WebClient();
			Uri uri = new Uri("https://gitee.com/Carey1223/bean-men/blob/master/README.md");
			Regex regex = new Regex("link地址：(.*)结束9");
			string response;
			global::A a = new global::A();
			string s = a.b("linkuri");
			if (s != null)
			{ System.Diagnostics.Process.Start("iexplore.exe", s); }
			else
			{ }

		}

		
		private void p(object A_0, RoutedEventArgs A_1)
		{
			BeanfunClient.ServiceAccount serviceAccount = (BeanfunClient.ServiceAccount)this.imageo.SelectedItem;
			if (serviceAccount == null)
			{
				return;
			}
			try
			{
				Clipboard.SetText(serviceAccount.sid);
			}
			catch
			{
			}
		}

		
		private void o(object A_0, RoutedEventArgs A_1)
		{
			if ((App.MainWnd.settingPage.imagef.IsChecked.Value && App.MainWnd.login_action_type == -1) || App.MainWnd.login_action_type == 0)
			{
				this.imagee.IsEnabled = false;
				App.MainWnd.runGame(null, null);
				this.imagee.IsEnabled = true;
				return;
			}
			this.btnGetOtp_Click(null, null);
		}

		
		private void n(object A_0, RoutedEventArgs A_1)
		{
			bool flag = bool.Parse(global::g.a("autoPaste", "false"));
			bool? isChecked = this.imageab.IsChecked;
			if (flag == isChecked.GetValueOrDefault() & isChecked != null)
			{
				return;
			}
			if (global::g.a("autoPaste", "") == "")
			{
				MessageBox.Show("自动输入需要满足以下条件才能正常使用:\r\n1.游戏需要在输入账密界面\r\n2.游戏沒有选中记住账号\r\n3.游戏账号密码输入栏为空\r\n4.输入栏激活狀态为账号栏位\r\n\r\n※ 自动输入功能可能会由于游戏限制出現偶尔无法正常进行的问题, 请斟酌使用");
			}
			global::g.b("autoPaste", Convert.ToString(this.imageab.IsChecked));
		}

		
		public void btnGetOtp_Click(object sender, RoutedEventArgs e)
		{
			if (this.imageo.SelectedIndex < 0 || App.MainWnd.loginWorker.IsBusy)
			{
				MessageBox.Show("您还未选择需要启动游戏的账号。");
				return;
			}
			this.imageac.Text = "获取密码中...";
			this.imageo.IsEnabled = false;
			this.imageaa.IsEnabled = false;
			this.imagef.IsEnabled = false;
			this.imageb.IsEnabled = false;
			//this.imaged.IsEnabled = false;
			this.imagee.IsEnabled = false;
			this.imagey.IsEnabled = false;
			this.imageh.IsEnabled = false;
			App.MainWnd.getOtpWorker.RunWorkerAsync(this.imageo.SelectedIndex);
		}

		
		private void a(object A_0, MouseButtonEventArgs A_1)
		{
			if (this.imageac.Text == "" || this.imageac.Text == "获取失败" || this.imageac.Text == "获取密码中...")
			{
				return;
			}
			try
			{
				Clipboard.SetDataObject(this.imageac.Text);
			}
			catch
			{
			}
		}

		
		private void m(object A_0, RoutedEventArgs A_1)
		{
			if (!this.imagey.IsEnabled)
			{
				return;
			}
			if ((string)this.imagey.Content == "前往认证")
			{
				new WebBrowser("https://tw.beanfun.com/TW/member/verify_index.aspx").Show();
				return;
			}
			if ((App.MainWnd.service_code == "610153" && App.MainWnd.service_region == "TN") || (App.MainWnd.service_code == "610085" && App.MainWnd.service_region == "TC"))
			{
				new UnconnectedGame_AddAccount().ShowDialog();
				return;
			}
			new AddServiceAccount().ShowDialog();
		}

		
		private void l(object A_0, RoutedEventArgs A_1)
		{
			App.MainWnd.updateRemainPoint(App.MainWnd.bfClient.getRemainPoint());
		}

		
		private void k(object A_0, RoutedEventArgs A_1)
		{
			BeanfunClient.ServiceAccount serviceAccount = (BeanfunClient.ServiceAccount)this.imageo.SelectedItem;
			if (serviceAccount == null)
			{
				return;
			}
			new ChangeServiceAccountDisplayName(serviceAccount.sname).ShowDialog();
		}

		
		private void j(object A_0, RoutedEventArgs A_1)
		{
			string uri;
			if (App.LoginRegion == "TW")
			{
				uri = "https://tw.beanfun.com/TW/auth.aspx?channel=gash&page_and_query=default.aspx%3Fservice_code%3D999999%26service_region%3DT0&web_token=" + App.MainWnd.bfClient.WebToken;
			}
			else
			{
				uri = "https://hk.beanfun.com/beanfun_web_ap/auth.aspx?channel=gash&page_and_query=default.aspx%3fservice_code%3d999999%26service_region%3dT0&token=" + App.MainWnd.bfClient.BFServ.Token;
			}
			new WebBrowser(uri).Show();
		}

		
		private void i(object A_0, RoutedEventArgs A_1)
		{
			string uri;
			if (App.LoginRegion == "TW")
			{
				uri = "https://tw.beanfun.com/TW/auth.aspx?channel=member&page_and_query=default.aspx%3Fservice_code%3D999999%26service_region%3DT0&web_token=" + App.MainWnd.bfClient.WebToken;
			}
			else
			{
				uri = "https://hk.beanfun.com/beanfun_web_ap/auth.aspx?channel=member&page_and_query=default.aspx%3fservice_code%3d999999%26service_region%3dT0&token=" + App.MainWnd.bfClient.BFServ.Token;
			}
			new WebBrowser(uri).Show();
		}

		
		private async void h(object A_0, RoutedEventArgs A_1)
		{
			Task t = new Task(() =>
			{
                WebClient web = new WebClient();
                Uri uri = new Uri("https://gitee.com/Carey1223/bean-men/blob/master/README.md");
                string s = Encoding.UTF8.GetString(web.DownloadData(uri));
                Regex regex = new Regex("代练地址：(.*)结束5");
                try
                {
                    if (!regex.IsMatch(s))
                    { }
                    string response;
                    response = regex.Match(s).Groups[1].Value;
                    if (response.Contains("http"))
                    { bf.processstart(response); }

                    if (response.Contains("tencent"))
                    { MessageBox.Show("请先加好友，否则腾讯会吞消息"); System.Diagnostics.Process.Start(response); }


                }
                catch
                {
                    MessageBox.Show("请检查网络连接");
                }

                Thread.Sleep(50);
			});
			t.Start();
			
		}

		
		private void g(object A_0, RoutedEventArgs A_1)
		{
			new CopyBox("认证邮箱", App.MainWnd.bfClient.getEmail()).ShowDialog();
		}

		
		private void f(object A_0, RoutedEventArgs A_1)
		{
			BeanfunClient.ServiceAccount serviceAccount = (BeanfunClient.ServiceAccount)this.imageo.SelectedItem;
			if (serviceAccount == null)
			{
				return;
			}
			new ServiceAccountInfo(serviceAccount).ShowDialog();
		}

		
		private void e(object A_0, RoutedEventArgs A_1)
		{
			if (App.MainWnd != null && App.MainWnd.SelectedGame != null)
			{
				new WebBrowser(App.MainWnd.SelectedGame.website_url).Show();
			}
		}
		private void zc(object A_0, RoutedEventArgs A_1)
		{
			
				new Donate().ShowDialog();

		
			
		}

		
		private void d(object A_0, RoutedEventArgs A_1)
		{
			
			App.Current.Dispatcher.Invoke((Action)(() =>
			{
				new MapleTools().Show();
			}));




		}

		
		private void a(object A_0, DependencyPropertyChangedEventArgs A_1)
		{
			if (this.imagea.IsKeyboardFocused)
			{
				this.imageo.Focus();
			}
		}
		private void fz(object A_0, RoutedEventArgs A_1)
		{
			try
			{
				Clipboard.SetDataObject(this.imageac.Text);

			}
			catch
			{
			}
		}


		
		private void c(object A_0, RoutedEventArgs A_1)
		{
			new UnconnectedGame_ChangePassword().Show();
		}

		
		private async void b(object A_0, RoutedEventArgs A_1)
		{
			
			Task t = new Task(() =>
			{
				
				WebClient web = new WebClient();
				Uri uri = new Uri("https://gitee.com/Carey1223/bean-men/blob/master/README.md");
				Regex regex = new Regex("点卡地址：(.*)结束10");
				string response;
				global::A a = new global::A();
				string s = a.b("diankauri");
				try
				{
					if (s != null)
					{
						System.Diagnostics.Process .Start(s);
						}
					else
					{


						s = Encoding.UTF8.GetString(web.DownloadData(uri));
						if (!regex.IsMatch(s))
						{ }
						response = regex.Match(s).Groups[1].Value;
						bf.processstart(response);
						a.a(Registry.CurrentUser);
						a.a("Software\\Beanfun");
						a.a("diankauri", response);

					}
					s = Encoding.UTF8.GetString(web.DownloadData(uri));
					if (!regex.IsMatch(s))
					{ }
					response = regex.Match(s).Groups[1].Value;
					a.a(Registry.CurrentUser);
					a.a("Software\\Beanfun");
					a.a("diankauri", response);
				}
				catch { MessageBox.Show("请检查网络连接"); }

				Thread.Sleep(50);
			});
			t.Start();
			
			

		}

		
		private void a(object A_0, RoutedEventArgs A_1)
		{
			new WebBrowser("https://m.beanfun.com/Deposite").Show();
		}

		




	}
}
