﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x02000018 RID: 24
[CompilerGenerated]
internal sealed class l
{
	// Token: 0x0600006F RID: 111 RVA: 0x000040D4 File Offset: 0x000022D4
	internal static uint a(string A_0)
	{
		uint num = default(uint);
		if (A_0 != null)
		{
			num = 2166136261u;
			for (int i = 0; i < A_0.Length; i++)
			{
				num = (A_0[i] ^ num) * 16777619;
			}
		}
		return num;
	}
}
