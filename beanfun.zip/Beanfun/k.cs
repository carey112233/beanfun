﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Xml;
using Beanfun;

// Token: 0x02000017 RID: 23
internal class k
{
	// Token: 0x06000066 RID: 102 RVA: 0x00003CD8 File Offset: 0x00001ED8
	internal static void a(Version A_0, bool A_1)
	{
		string a_ = k.m_a + "VersionInfo.xml";
		try
		{
			MemoryStream inStream = new d(10000).a(a_);
			XmlDocument xmlDocument = new XmlDocument();
			xmlDocument.Load(inStream);
			k.a(xmlDocument, A_0, A_1);
		}
		catch (Exception)
		{
		}
	}

	// Token: 0x06000067 RID: 103 RVA: 0x00003D30 File Offset: 0x00001F30
	private static void a(XmlDocument A_0, Version A_1, bool A_2)
	{
		string value = A_0.SelectSingleNode("/VersionInfo/Version/text()").Value;
		if (k.a(A_1, new Version(value)))
		{
			try
			{
				Version version = new Version(A_0.SelectSingleNode("/VersionInfo/Version/text()").Value);
				string value2 = A_0.SelectSingleNode("/VersionInfo/Date/text()").Value;
				string value3 = A_0.SelectSingleNode("/VersionInfo/Note/text()").Value;
				if (MessageBox.Show(string.Format("检测到新版本 {0}.{1}.{2}({3}) 当前: {4}.{5}.{6}({7})\r\n\r\n{8}\r\n", new object[]
				{
					version.Major,
					version.Minor,
					version.Build,
					version.Revision,
					A_1.Major,
					A_1.Minor,
					A_1.Build,
					A_1.Revision,
					value3
				}) + "\r\n是否更新(会重启软件)？", "更新檢測", MessageBoxButton.OKCancel) == MessageBoxResult.OK)
				{
					k.a(A_0);
				}
				return;
			}
			catch (Exception)
			{
				return;
			}
		}
		if (A_2)
		{
			MessageBox.Show("未检测到有更新。", "更新检测", MessageBoxButton.OK);
		}
	}

	// Token: 0x06000068 RID: 104 RVA: 0x00003E64 File Offset: 0x00002064
	private static void a(XmlDocument A_0)
	{
		string value = A_0.SelectSingleNode("/VersionInfo/Url/text()").Value;
		Version a_ = new Version(A_0.SelectSingleNode("/VersionInfo/UpdaterVersion/text()").Value);
		string text = Environment.CurrentDirectory + "\\";
		k.m_c.Clear();
		if (!File.Exists(text + "BFUpdater.exe") || k.a(k.a(text + "BFUpdater.exe"), a_))
		{
			k.a(k.m_c, k.m_a + "BFUpdater.exe", text);
		}
		k.a(k.m_c, value, text);
		k.m_b = new DownloadProgressBar(k.m_c, "正在下載更新...", text, true);
		k.m_b.Closing += k.a;
		k.m_b.ShowDialog();
	}

	// Token: 0x06000069 RID: 105 RVA: 0x00003F3C File Offset: 0x0000213C
	private static void a(object A_0, CancelEventArgs A_1)
	{
		if (k.m_b.TaskFileNum > 0 && k.m_b.TaskFileNum == k.m_b.DownloadedFileNum)
		{
			Process.Start(Environment.CurrentDirectory + "\\BFUpdater.exe");
			return;
		}
		string str = Environment.CurrentDirectory + "\\";
		foreach (string text in k.m_c)
		{
			string str2 = text.Substring(text.LastIndexOf("/") + 1);
			string path = str + str2;
			if (File.Exists(path))
			{
				File.Delete(path);
			}
		}
	}

	// Token: 0x0600006A RID: 106 RVA: 0x00003FF8 File Offset: 0x000021F8
	private static void a(List<string> A_0, string A_1, string A_2)
	{
		A_2 += A_1.Substring(A_1.LastIndexOf("/") + 1);
		if (File.Exists(A_2))
		{
			File.Delete(A_2);
		}
		A_0.Add(A_1);
	}

	// Token: 0x0600006B RID: 107 RVA: 0x0000402C File Offset: 0x0000222C
	private static Version a(string A_0)
	{
		string text = null;
		try
		{
			text = FileVersionInfo.GetVersionInfo(A_0).FileVersion;
		}
		catch
		{
		}
		return new Version((text == null) ? "0.0.0.0" : text);
	}

	// Token: 0x0600006C RID: 108 RVA: 0x0000406C File Offset: 0x0000226C
	private static bool a(Version A_0, Version A_1)
	{
		return A_0 < A_1;
	}

	// Token: 0x0600006D RID: 109 RVA: 0x00004075 File Offset: 0x00002275
	public k()
	{
	}

	// Token: 0x0600006E RID: 110 RVA: 0x00004080 File Offset: 0x00002280
	// Note: this type is marked as 'beforefieldinit'.
	static k()
	{
	}

	// Token: 0x04000052 RID: 82
	private static string m_a = "https://raw.githubusercontent.com/carey111/Beanfun/" + (g.a("updateChannel", "Stable").Equals("Stable") ? "master" : "beta") + "/";

	// Token: 0x04000053 RID: 83
	private static DownloadProgressBar m_b;

	// Token: 0x04000054 RID: 84
	private static List<string> m_c = new List<string>();
}
