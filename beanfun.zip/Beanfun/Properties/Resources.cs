﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace Beanfun.Properties
{
		[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "15.0.0.0")]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	public class Resources
	{
				internal Resources()
		{
		}

				// (get) Token: 0x06000292 RID: 658 RVA: 0x00014735 File Offset: 0x00012935
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		public static ResourceManager ResourceManager
		{
			get
			{
				if (Resources.a == null)
				{
					Resources.a = new ResourceManager("Beanfun.Properties.Resources", typeof(Resources).Assembly);
				}
				return Resources.a;
			}
		}

				// (get) Token: 0x06000293 RID: 659 RVA: 0x00014761 File Offset: 0x00012961
		// (set) Token: 0x06000294 RID: 660 RVA: 0x00014768 File Offset: 0x00012968
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		public static CultureInfo Culture
		{
			get
			{
				return Resources.b;
			}
			set
			{
				Resources.b = value;
			}
		}

				// (get) Token: 0x06000295 RID: 661 RVA: 0x00014770 File Offset: 0x00012970
		public static Icon icon
		{
			get
			{
				return (Icon)Resources.ResourceManager.GetObject("icon", Resources.b);
			}
		}

				// (get) Token: 0x06000296 RID: 662 RVA: 0x0001478B File Offset: 0x0001298B
		public static byte[] LoaderDll
		{
			get
			{
				return (byte[])Resources.ResourceManager.GetObject("LoaderDll", Resources.b);
			}
		}

				// (get) Token: 0x06000297 RID: 663 RVA: 0x000147A6 File Offset: 0x000129A6
		public static byte[] LocaleEmulator
		{
			get
			{
				return (byte[])Resources.ResourceManager.GetObject("LocaleEmulator", Resources.b);
			}
		}

				// (get) Token: 0x06000298 RID: 664 RVA: 0x000147C1 File Offset: 0x000129C1
		public static Bitmap logo
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("logo", Resources.b);
			}
		}

				// (get) Token: 0x06000299 RID: 665 RVA: 0x000147DC File Offset: 0x000129DC
		public static Bitmap QRCode_Alipay
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("QRCode_Alipay", Resources.b);
			}
		}

				// (get) Token: 0x0600029A RID: 666 RVA: 0x000147F7 File Offset: 0x000129F7
		public static Bitmap QRCode_QQPay
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("QRCode_QQPay", Resources.b);
			}
		}

				// (get) Token: 0x0600029B RID: 667 RVA: 0x00014812 File Offset: 0x00012A12
		public static Bitmap QRCode_WeChat
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("QRCode_WeChat", Resources.b);
			}
		}

				// (get) Token: 0x0600029C RID: 668 RVA: 0x0001482D File Offset: 0x00012A2D
		public static Bitmap refresh
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("refresh", Resources.b);
			}
		}

				// (get) Token: 0x0600029D RID: 669 RVA: 0x00014848 File Offset: 0x00012A48
		public static Bitmap Scroll_Black
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("Scroll_Black", Resources.b);
			}
		}

				// (get) Token: 0x0600029E RID: 670 RVA: 0x00014863 File Offset: 0x00012A63
		public static Bitmap Scroll_BM
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("Scroll_BM", Resources.b);
			}
		}

				// (get) Token: 0x0600029F RID: 671 RVA: 0x0001487E File Offset: 0x00012A7E
		public static Bitmap Scroll_JD
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("Scroll_JD", Resources.b);
			}
		}

				// (get) Token: 0x060002A0 RID: 672 RVA: 0x00014899 File Offset: 0x00012A99
		public static Bitmap Scroll_Other
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("Scroll_Other", Resources.b);
			}
		}

				// (get) Token: 0x060002A1 RID: 673 RVA: 0x000148B4 File Offset: 0x00012AB4
		public static Bitmap Scroll_Red
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("Scroll_Red", Resources.b);
			}
		}

				// (get) Token: 0x060002A2 RID: 674 RVA: 0x000148CF File Offset: 0x00012ACF
		public static Bitmap Scroll_SM
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("Scroll_SM", Resources.b);
			}
		}

				// (get) Token: 0x060002A3 RID: 675 RVA: 0x000148EA File Offset: 0x00012AEA
		public static Bitmap Scroll_V
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("Scroll_V", Resources.b);
			}
		}

				// (get) Token: 0x060002A4 RID: 676 RVA: 0x00014905 File Offset: 0x00012B05
		public static Bitmap Scroll_X
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("Scroll_X", Resources.b);
			}
		}

				private static ResourceManager a;

				private static CultureInfo b;
	}
}
