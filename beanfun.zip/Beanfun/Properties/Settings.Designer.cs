﻿using System;
using System.CodeDom.Compiler;
using System.Configuration;
using System.Runtime.CompilerServices;

namespace Beanfun.Properties
{
		[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "15.8.0.0")]
	[CompilerGenerated]
	internal sealed partial class Settings : ApplicationSettingsBase
	{
				// (get) Token: 0x060002A5 RID: 677 RVA: 0x00014920 File Offset: 0x00012B20
		public static Settings Default
		{
			get
			{
				return Settings.a;
			}
		}

				private static Settings a = (Settings)SettingsBase.Synchronized(new Settings());
	}
}
