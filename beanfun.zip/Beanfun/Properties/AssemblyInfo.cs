﻿using System;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: Guid("24238732-c686-4921-9f1c-5159a4344638")]
[assembly: ComVisible(true)]
[assembly: NeutralResourcesLanguage("zh-Hans")]
[assembly: Dotfuscator("238060:0:0:5.36.0.7050", 0)]
[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: AssemblyTitle("缤放")]
[assembly: AssemblyDescription("第三方乐豆客户端")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Beanfun")]
[assembly: AssemblyCopyright("Copyright © 2017-2019")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyVersion("2.9.9.28699")]
