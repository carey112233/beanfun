﻿using System;

internal enum i
{
	
	a,

	b
}
