﻿using System;
using System.Configuration;
using System.IO;

// Token: 0x02000013 RID: 19
internal class g
{
	// Token: 0x06000051 RID: 81 RVA: 0x00003AB0 File Offset: 0x00001CB0
	public static void b(string A_0, string A_1)
	{
		try
		{
			Configuration configuration = ConfigurationManager.OpenMappedExeConfiguration(new ExeConfigurationFileMap
			{
				ExeConfigFilename = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\Beanfun\\Config.xml"
			}, ConfigurationUserLevel.None);
			if (configuration.AppSettings.Settings[A_0] == null)
			{
				if (A_1 != null)
				{
					configuration.AppSettings.Settings.Add(A_0, A_1);
				}
			}
			else if (A_1 == null)
			{
				configuration.AppSettings.Settings.Remove(A_0);
			}
			else
			{
				configuration.AppSettings.Settings[A_0].Value = A_1;
			}
			configuration.Save(ConfigurationSaveMode.Modified);
			ConfigurationManager.RefreshSection("appSettings");
		}
		catch
		{
			try
			{
				foreach (FileSystemInfo fileSystemInfo in new DirectoryInfo(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\Beanfun").GetFileSystemInfos("Config.xml"))
				{
					if (fileSystemInfo is DirectoryInfo)
					{
						new DirectoryInfo(fileSystemInfo.FullName).Delete(true);
					}
					else
					{
						File.Delete(fileSystemInfo.FullName);
					}
				}
				g.b(A_0, A_1);
			}
			catch
			{
			}
		}
	}

	// Token: 0x06000052 RID: 82 RVA: 0x00003BD0 File Offset: 0x00001DD0
	public static string a(string A_0)
	{
		return g.a(A_0, string.Empty);
	}

	// Token: 0x06000053 RID: 83 RVA: 0x00003BE0 File Offset: 0x00001DE0
	public static string a(string A_0, string A_1)
	{
		string result;
		try
		{
			Configuration configuration = ConfigurationManager.OpenMappedExeConfiguration(new ExeConfigurationFileMap
			{
				ExeConfigFilename = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\Beanfun\\Config.xml"
			}, ConfigurationUserLevel.None);
			result = ((configuration.AppSettings.Settings[A_0] == null) ? A_1 : configuration.AppSettings.Settings[A_0].Value);
		}
		catch
		{
			result = A_1;
		}
		return result;
	}

	// Token: 0x06000054 RID: 84 RVA: 0x00003C58 File Offset: 0x00001E58
	public g()
	{
	}
}
