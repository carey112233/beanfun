﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Amemiya.Extensions
{
	public static class ArrayExtensions
	{

		public static byte[] StructToBytes(object structObj)
		{
			int num = Marshal.SizeOf(structObj);
			IntPtr intPtr = Marshal.AllocHGlobal(num);
			try
			{
				Marshal.StructureToPtr(structObj, intPtr, fDeleteOld: true);
				byte[] array = new byte[num];
				Marshal.Copy(intPtr, array, 0, num);
				return array;
			}
			finally
			{
				Marshal.FreeHGlobal(intPtr);
			}
		}

		public static T[] CombineWith<T>(this T[] source, T[] with)
		{
			if (source == null || source.Length == 0)
			{
				return with;
			}
			T[] array = new T[source.Length + with.Length];
			array.SetRange(source, 0);
			array.SetRange(with, source.Length);
			return array;
		}

		public static bool EqualWith<T>(this T[] source, T[] compareWith)
		{
			if (source.Length != compareWith.Length)
			{
				return false;
			}
			if (source.Where((T A_0, int A_1) => !EqualityComparer<T>.Default.Equals(A_0, compareWith[A_1])).Any())
			{
				return false;
			}
			return true;
		}

		public static byte[] ExpandTo(this byte[] source, int newLength)
		{
			if (source.Length > newLength)
			{
				return source;
			}
			byte[] array = new byte[newLength];
			array.FillWith((byte)0);
			array.SetRange(source, 0);
			return array;
		}

		public static void FillWith<T>(this T[] source, T with)
		{
			for (int i = 0; i < source.Length; i++)
			{
				source[i] = with;
			}
		}

		public static int IndexOf<T>(this T[] source, T[] arrayToFind, int startAt, bool isBackward)
		{
			if (isBackward)
			{
				for (int num = startAt - arrayToFind.Length; num >= 0; num--)
				{
					if (source.Slice(num, arrayToFind.Length + num).EqualWith(arrayToFind))
					{
						return num;
					}
				}
				return -1;
			}
			for (int i = startAt; i <= source.Length - arrayToFind.Length; i++)
			{
				if (source.Slice(i, arrayToFind.Length + i).EqualWith(arrayToFind))
				{
					return i;
				}
			}
			return -1;
		}

		public static void SetRange<T>(this T[] source, T[] bytesValue, int startFrom)
		{
			if (source.Length < bytesValue.Length + startFrom)
			{
				throw new Exception("dest too small");
			}
			Array.Copy(bytesValue, 0, source, startFrom, bytesValue.Length);
		}

		public static T[] Slice<T>(this T[] source, int start, int end)
		{
			if (end < 0)
			{
				end = source.Length + end;
			}
			int num = end - start;
			T[] array = new T[num];
			for (int i = 0; i < num; i++)
			{
				array[i] = source[i + start];
			}
			return array;
		}
	}
}
