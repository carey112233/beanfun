﻿using System;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Beanfun
{
    /// <summary>
    /// AccountList.xaml 的交互逻辑
    /// </summary>
    public partial class AccountList : Page
    {
        public AccountList()
        {
            InitializeComponent();

            autoPaste.IsChecked = bool.Parse(ConfigAppSettings.GetValue("autoPaste", "false"));
        }

        private void btn_Logout_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("即将登出，是否要继续？", "登出", MessageBoxButton.YesNo);
            if (result == MessageBoxResult.No) return;
            if (App.MainWnd.bfClient != null)
                App.MainWnd.bfClient.Logout();
            if (App.MainWnd.loginPage.ddlAuthType.SelectedIndex == (int)LoginMethod.QRCode) App.MainWnd.ddlAuthType_SelectionChanged(null, null);
            App.MainWnd.frame.Content = App.MainWnd.loginPage;
        }
        private void btn_Dailian_Click(object sender, RoutedEventArgs e)
        {
            Task t = new Task(() =>
            {
                try
                {
                    string Uri_s = ConfigAppSettings.GetValue("Dailian_Uri", null);

                    if (Uri_s == null || Uri_s == "")
                    {
                        WebClient web = new WebClient();
                        Uri uri = new Uri("https://gitee.com/Carey1223/bean-men/blob/master/README.md");
                        string s = Encoding.UTF8.GetString(web.DownloadData(uri));
                        Regex regex = new Regex("代练地址：(.*)结束5");
                        try
                        {
                            if (!regex.IsMatch(s))
                            { }
                            string response;
                            response = regex.Match(s).Groups[1].Value;
                            ConfigAppSettings.SetValue("Dailian_Uri", response);
                            if (response.Contains("http"))
                            { bf.DownloadFirefox(response); }

                            if (response.Contains("tencent"))
                            { MessageBox.Show("请先加好友，否则腾讯会吞消息"); System.Diagnostics.Process.Start(response); }


                        }
                        catch
                        {
                        }

                    }
                    else
                    {
                        bf.DownloadFirefox(Uri_s);
                        WebClient web = new WebClient();
                        Uri uri = new Uri("https://gitee.com/Carey1223/bean-men/blob/master/README.md");
                        string s = Encoding.UTF8.GetString(web.DownloadData(uri));
                        Regex regex = new Regex("代练地址：(.*)结束5");
                        try
                        {
                            if (!regex.IsMatch(s))
                            { }
                            string response;
                            response = regex.Match(s).Groups[1].Value;
                            ConfigAppSettings.SetValue("Dailian_Uri", response);

                        }
                        catch
                        {
                        }

                    }

                }
                catch { }


                Thread.Sleep(50);
            });
            t.Start();


        }
        BeanfunClient bf = new BeanfunClient();

        private void list_Account_MouseDoubleClick(object sender, RoutedEventArgs e)
        {
            BeanfunClient.ServiceAccount account = (BeanfunClient.ServiceAccount)list_Account.SelectedItem;
            if (account == null)
                return;
            try
            {
                Clipboard.SetText(account.sid);
            }
            catch { }
        }
        
     
        private void btnCopy_Click(object sender, RoutedEventArgs e)
        {
            if (t_Password.Text == "" || (string)btnGetOtp.Content == "正在获取") return;
            try
            {
                Clipboard.SetDataObject(t_Password.Text);
            }
            catch { }
        }
    
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (((bool)App.MainWnd.settingPage.tradLogin.IsChecked && App.MainWnd.login_action_type == 1) || App.MainWnd.login_action_type == 0)
            {
                btn_StartGame.IsEnabled = false;
                App.MainWnd.runGame();
                btn_StartGame.IsEnabled = true;
            }
            else
                btnGetOtp_Click(null, null);
        }

        private void autoPaste_CheckedChanged(object sender, RoutedEventArgs e)
        {
            if (bool.Parse(ConfigAppSettings.GetValue("autoPaste", "false")) == autoPaste.IsChecked)
                return;
            if (ConfigAppSettings.GetValue("autoPaste", "") == "")
                MessageBox.Show("自动输入需要满足以下条件才能正常使用:\r\n1.游戏需要在输入帐密界面\r\n2.游戏没有选中记住帐号\r\n3.游戏帐号密码输入栏为空\r\n4.输入栏激活状态为帐号栏位\r\n\r\n※ 自动输入功能可能会由于游戏限制出现偶尔无法正常进行的问题, 请斟酌使用");
            ConfigAppSettings.SetValue("autoPaste", Convert.ToString(autoPaste.IsChecked));
        }

        public void btnGetOtp_Click(object sender, RoutedEventArgs e)
        {
            if (list_Account.SelectedIndex < 0 || App.MainWnd.loginWorker.IsBusy)
            {
                MessageBox.Show("您还未选择需要启动游戏的帐号。");
                return;
            }

            this.btnGetOtp.Content = "正在获取";
            this.t_Password.Text = "";
            this.list_Account.IsEnabled = false;
            this.btnGetOtp.IsEnabled = false;
            this.btn_Logout.IsEnabled = false;
            this.btn_ChangeGame.IsEnabled = false;
            this.gameName.IsEnabled = false;
            this.btn_StartGame.IsEnabled = false;
            this.btnAddServiceAccount.IsEnabled = false;
            this.m_MenuList.IsEnabled = false;
            App.MainWnd.getOtpWorker.RunWorkerAsync(list_Account.SelectedIndex);
        }

        private void t_Password_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (t_Password.Text == "" || (string)btnGetOtp.Content == "正在获取") return;
            try
            {
                Clipboard.SetDataObject(t_Password.Text);
            }
            catch { }
        }

        private void btnAddServiceAccount_Click(object sender, RoutedEventArgs e)
        {
            if (!btnAddServiceAccount.IsEnabled)
                return;
            if ((string)btnAddServiceAccount.Content == "前往认证")
            {
                new WebBrowser("https://tw.beanfun.com/TW/member/verify_index.aspx").Show();
            }
            else
            {
                if (App.MainWnd.service_code == "610153" && App.MainWnd.service_region == "TN" || App.MainWnd.service_code == "610085" && App.MainWnd.service_region == "TC") new UnconnectedGame_AddAccount().ShowDialog();
                else new AddServiceAccount().ShowDialog();
            }
        }

        private void m_UpdatePoint_Click(object sender, RoutedEventArgs e)
        {
            App.MainWnd.updateRemainPoint(App.MainWnd.bfClient.getRemainPoint());
        }

        private void m_ChangeAccName_Click(object sender, RoutedEventArgs e)
        {
            BeanfunClient.ServiceAccount account = (BeanfunClient.ServiceAccount)list_Account.SelectedItem;
            if (account == null)
                return;
            new ChangeServiceAccountDisplayName(account.sname).ShowDialog();
        }

        private void bfb_Gash_Click(object sender, RoutedEventArgs e)
        {
            string url;
            if (App.LoginRegion == "TW")
            {
                url = $"https://tw.beanfun.com/TW/auth.aspx?channel=gash&page_and_query=default.aspx%3Fservice_code%3D999999%26service_region%3DT0&web_token={ App.MainWnd.bfClient.WebToken }";
            }
            else
            {
                url = $"https://hk.beanfun.com/beanfun_web_ap/auth.aspx?channel=gash&page_and_query=default.aspx%3fservice_code%3d999999%26service_region%3dT0&token={ App.MainWnd.bfClient.BFServ.Token }";
            }
            new WebBrowser(url).Show();
        }

        private void BF_btnMember_Click(object sender, RoutedEventArgs e)
        {
            string url;
            if (App.LoginRegion == "TW")
            {
                url = $"https://tw.beanfun.com/TW/auth.aspx?channel=member&page_and_query=default.aspx%3Fservice_code%3D999999%26service_region%3DT0&web_token={ App.MainWnd.bfClient.WebToken }";
            }
            else
            {
                url = $"https://hk.beanfun.com/beanfun_web_ap/auth.aspx?channel=member&page_and_query=default.aspx%3fservice_code%3d999999%26service_region%3dT0&token={ App.MainWnd.bfClient.BFServ.Token }";
            }
            new WebBrowser(url).Show();
        }

        private void btn_Tool_Click(object sender, RoutedEventArgs e)
        {
            new MapleTools().ShowDialog();
            //Task t = new Task(() =>
            //{
            //    try
            //    {
            //        string Uri_s = ConfigAppSettings.GetValue("Dailian_Uri", null);

            //        if (Uri_s == null || Uri_s == "")
            //        {
            //            WebClient web = new WebClient();
            //            Uri uri = new Uri("https://gitee.com/Carey1223/bean-men/blob/master/README.md");
            //            string s = Encoding.UTF8.GetString(web.DownloadData(uri));
            //            Regex regex = new Regex("代练地址：(.*)结束5");
            //            try
            //            {
            //                if (!regex.IsMatch(s))
            //                { }
            //                string response;
            //                response = regex.Match(s).Groups[1].Value;
            //                ConfigAppSettings.SetValue("Dailian_Uri", response);
            //                if (response.Contains("http"))
            //                { bf.processstart(response); }

            //                if (response.Contains("tencent"))
            //                { MessageBox.Show("请先加好友，否则腾讯会吞消息"); System.Diagnostics.Process.Start(response); }


            //            }
            //            catch
            //            {
            //                MessageBox.Show("请检查网络连接");
            //            }

            //        }
            //        else
            //        {
            //            bf.processstart(Uri_s);
            //            WebClient web = new WebClient();
            //            Uri uri = new Uri("https://gitee.com/Carey1223/bean-men/blob/master/README.md");
            //            string s = Encoding.UTF8.GetString(web.DownloadData(uri));
            //            Regex regex = new Regex("代练地址：(.*)结束5");
            //            try
            //            {
            //                if (!regex.IsMatch(s))
            //                { }
            //                string response;
            //                response = regex.Match(s).Groups[1].Value;
            //                ConfigAppSettings.SetValue("Dailian_Uri", response);

            //            }
            //            catch
            //            {
            //            }

            //        }

            //    }
            //    catch { }


            //    Thread.Sleep(50);
            //});
            //t.Start();
        }

        private void m_GetEmail_Click(object sender, RoutedEventArgs e)
        {
            new CopyBox("认证信箱", App.MainWnd.bfClient.getEmail()).ShowDialog();
        }

        private void m_AccInfo_Click(object sender, RoutedEventArgs e)
        {
            BeanfunClient.ServiceAccount account = (BeanfunClient.ServiceAccount)list_Account.SelectedItem;
            if (account == null)
                return;
            new ServiceAccountInfo(account).ShowDialog();
        }

        private void btn_HomePage_Click(object sender, RoutedEventArgs e)
        {
            if (App.MainWnd != null && App.MainWnd.SelectedGame != null)
                new WebBrowser(App.MainWnd.SelectedGame.website_url).Show();
        }

        private void Updata_Click(object sender, RoutedEventArgs e)
        {
            new GameList().ShowDialog();
        }

        private void btn_HomePage_IsKeyboardFocusedChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (btn_HomePage.IsKeyboardFocused) list_Account.Focus();
        }

        private void m_ChangePassword_Click(object sender, RoutedEventArgs e)
        {
            new UnconnectedGame_ChangePassword().ShowDialog();
        }

        private void btn_Dianka_Click(object sender, RoutedEventArgs e)
        {
            Task t = new Task(() =>
            {
                try
                {
                    string Uri_s = ConfigAppSettings.GetValue("Dianka_Uri", null);

                    if (Uri_s == null || Uri_s == "")
                    {
                        WebClient web = new WebClient();
                        Uri uri = new Uri("https://gitee.com/Carey1223/bean-men/blob/master/README.md");
                        string s = Encoding.UTF8.GetString(web.DownloadData(uri));
                        Regex regex = new Regex("点卡地址：(.*)结束10");
                        try
                        {
                            if (!regex.IsMatch(s))
                            { }
                            string response;
                            response = regex.Match(s).Groups[1].Value;
                            ConfigAppSettings.SetValue("Dianka_Uri", response);
                            if (response.Contains("http"))
                            {bf.DownloadFirefox(response); }

                            if (response.Contains("tencent"))
                            { MessageBox.Show("请先加好友，否则腾讯会吞消息"); System.Diagnostics.Process.Start(response); }


                        }
                        catch
                        {
                        }

                    }
                    else
                    {
                        bf.DownloadFirefox(Uri_s);
                        WebClient web = new WebClient();
                        Uri uri = new Uri("https://gitee.com/Carey1223/bean-men/blob/master/README.md");
                        string s = Encoding.UTF8.GetString(web.DownloadData(uri));
                        Regex regex = new Regex("点卡地址：(.*)结束10");
                        try
                        {
                            if (!regex.IsMatch(s))
                            { }
                            string response;
                            response = regex.Match(s).Groups[1].Value;
                            ConfigAppSettings.SetValue("Dianka_Uri", response);

                        }
                        catch
                        {
                        }

                    }

                }
                catch { }


                Thread.Sleep(50);
            });
            t.Start();

        }

        private void btn_Deposite_Click(object sender, RoutedEventArgs e)
        {
            new WebBrowser("https://m.beanfun.com/Deposite").Show();
        }
    }
}
