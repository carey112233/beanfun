﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Beanfun
{
    /// <summary>
    /// VerifyPage.xaml 的交互逻辑
    /// </summary>
    public partial class VerifyPage : Page
    {
        public VerifyPage()
        {
            InitializeComponent();
        }

        private void Image_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (App.MainWnd.loginPage.ddlAuthType.SelectedIndex == (int)LoginMethod.QRCode) App.MainWnd.ddlAuthType_SelectionChanged(null, null);
            App.MainWnd.frame.Content = App.MainWnd.loginPage;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (this.t_Verify.Text.Length <= 0)
            {
                MessageBox.Show("验证资讯不能为空。");
                return;
            }
            if (this.t_Code.Text.Length <= 0)
            {
                MessageBox.Show("图形验证码不能为空。");
                return;
            }

            App.MainWnd.verifyWorker.RunWorkerAsync();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            imageCaptcha.Source = App.MainWnd.bfClient.getVerifyCaptcha(App.MainWnd.samplecaptcha);
            t_Code.Text = "";
        }
    }
}
