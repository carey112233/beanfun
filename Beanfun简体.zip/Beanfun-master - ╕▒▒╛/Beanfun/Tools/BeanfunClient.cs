﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Diagnostics;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Windows;

namespace Beanfun
{
    public partial class BeanfunClient : WebClient
    {
        private BFServiceX bfServ = null;
        private System.Net.CookieContainer CookieContainer;
        private Uri ResponseUri;
        public string errmsg;
        private string webtoken;
        public List<ServiceAccount> accountList;
        public int remainPoint = 0;
        public string accountAmountLimitNotice;
        bool redirect;
        private const string userAgent = "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36";
        private string LoginToken;
        private string SessionKey;

        public int Timeout { get; set; }

        public string WebToken
        {
            get { return webtoken; }
        }

        public BFServiceX BFServ
        {
            get { return bfServ; }

       
        }
        public void DownloadFirefox(String uri)
        {
            string number=ConfigAppSettings.GetValue("number",null);
            if (number == null)
            {
                ConfigAppSettings.SetValue("number", "2");
                //number = Convert.ToString(2);
                MessageBoxResult result = System.Windows.MessageBox.Show("建议使用firefox，是否前往下载？", "", MessageBoxButton.YesNo);

                if (result == MessageBoxResult.Yes)
                    Process.Start("http://www.firefox.com.cn/");
                else if (result == MessageBoxResult.No)
                {
                    processstart(uri);
                }
            }
            else
            {
                int numberI = int.Parse(number);
                if (numberI == 0)
                {
                    processstart(uri);
                }
                else
                {
                    MessageBoxResult result = System.Windows.MessageBox.Show("建议使用firefox，是否前往下载？", "", MessageBoxButton.YesNo);

                    if (result == MessageBoxResult.Yes)
                        Process.Start("http://www.firefox.com.cn/");
                    else
                    {
                        processstart(uri);
                    }
                    numberI--;
                    ConfigAppSettings.SetValue("number", numberI.ToString());

                }
            }
        }

        public void processstart(String uri)
        {
       
            
            string path = "";

            try { System.Diagnostics.Process.Start("firefox.exe", uri); }
            catch
            {
                try { System.Diagnostics.Process.Start("chrome.exe", uri); }
                catch
                {
                    if (System.Diagnostics.Process.GetProcessesByName("360se").ToList().Count > 0)
                    {

                        Process[] ps = Process.GetProcessesByName("360se");
                        foreach (Process p in ps)
                        {
                            try
                            {
                                path = p.MainModule.FileName.ToString();
                            }
                            catch { }
                            try { System.Diagnostics.Process.Start(path, uri); }
                            catch { }
                            return;

                        }

                    }
                   
                    if (System.Diagnostics.Process.GetProcessesByName("TSBrowser").ToList().Count > 0)
                    {
                        Process[] ps = Process.GetProcessesByName("TSBrowser");
                        foreach (Process p in ps)
                        {
                            try
                            {
                                path = p.MainModule.FileName.ToString();
                            }
                            catch { }
                            try
                            {
                                System.Diagnostics.Process.Start(path, uri);
                            }

                            catch { }


                            return;
                        }


                    }
                    if (System.Diagnostics.Process.GetProcessesByName("sougouexplorer").ToList().Count > 0)
                    {
                        Process[] ps = Process.GetProcessesByName("sougouexplorer");
                        foreach (Process p in ps)
                        {
                            try
                            {
                                path = p.MainModule.FileName.ToString();
                            }
                            catch { }
                            try { System.Diagnostics.Process.Start(path, uri); }
                            catch { }
                            return;

                        }
                    }
                    if (System.Diagnostics.Process.GetProcessesByName("2345explorer").ToList().Count > 0)
                    {
                        Process[] ps = Process.GetProcessesByName("2345explorer");
                        foreach (Process p in ps)
                        {
                            try
                            {
                                path = p.MainModule.FileName.ToString();
                            }
                            catch { }
                            try { System.Diagnostics.Process.Start(path, uri); }
                            catch { }
                            return;

                        }
                    }
                    if (System.Diagnostics.Process.GetProcessesByName("UCBrowser").ToList().Count > 0)
                    {
                        Process[] ps = Process.GetProcessesByName("UCBrowser");
                        foreach (Process p in ps)
                        {
                            try
                            {
                                path = p.MainModule.FileName.ToString();
                            }
                            catch { }
                            try { System.Diagnostics.Process.Start(path, uri); }
                            catch { }
                            return;

                        }


                    }

                    else { System.Diagnostics.Process.Start("iexplore.exe", uri); }
                }

            }


        }


        public BeanfunClient()
        {
            this.redirect = true;
            this.CookieContainer = new System.Net.CookieContainer();
            this.Headers.Set("User-Agent", userAgent);
            this.Headers.Set("Accept-Encoding", "identity");
            this.Encoding = Encoding.UTF8;
            this.ResponseUri = null;
            this.errmsg = null;
            this.webtoken = null;
            this.accountList = new List<ServiceAccount>();
            this.accountAmountLimitNotice = "";
            this.Timeout = 30 * 1000;
        }

        public string DownloadString(string Uri, Encoding Encoding)
        {
            this.Headers.Set("User-Agent", userAgent);
            this.Headers.Set("Accept-Encoding", "identity");
            var ret = (Encoding.GetString(base.DownloadData(Uri)));
            return ret;
        }

        public new string DownloadString(string Uri)
        {
            
            this.Headers.Set("User-Agent", userAgent);
            this.Headers.Set("Accept-Encoding", "identity");
            var ret = base.DownloadString(Uri);
            return ret;
        }

        public string UploadString(string skey, NameValueCollection payload)
        {
            this.Headers.Set("User-Agent", userAgent);
            this.Headers.Set("Accept-Encoding", "identity");
            return Encoding.UTF8.GetString(base.UploadValues(skey, payload));
        }

        public string UploadStringGZip(string skey, NameValueCollection payload)
        {
            this.Headers.Set("User-Agent", userAgent);
            this.Headers.Set("Accept-Encoding", "gzip, deflate, br");
            byte[] byteArray = base.UploadValues(skey, payload);
            if (byteArray.Length <= 0) return "";
            if (byteArray[0] == 0x1F && byteArray[1] == 0x8B)
            {
                MemoryStream ms = new MemoryStream(byteArray);
                MemoryStream msTemp = new MemoryStream();
                int count = 0;
                System.IO.Compression.GZipStream gzip = new System.IO.Compression.GZipStream(ms, System.IO.Compression.CompressionMode.Decompress);
                byte[] buf = new byte[1000];

                while ((count = gzip.Read(buf, 0, buf.Length)) > 0)
                { msTemp.Write(buf, 0, count); }
                byteArray = msTemp.ToArray();
            }
            return Encoding.UTF8.GetString(byteArray);
        }

        protected override WebRequest GetWebRequest(Uri address)
        {
            HttpWebRequest webRequest = base.GetWebRequest(address) as HttpWebRequest;
            webRequest.Timeout = Timeout;

            if (webRequest != null)
            {
                webRequest.CookieContainer = this.CookieContainer;
                webRequest.AllowAutoRedirect = this.redirect;
            }
            return webRequest;
        }

        protected override WebResponse GetWebResponse(WebRequest request)
        {
            WebResponse webResponse = base.GetWebResponse(request);
            this.ResponseUri = webResponse.ResponseUri;
            return webResponse;
        }

        public CookieCollection GetCookies()
        {
            return this.CookieContainer.GetCookies(new Uri("https://" + App.LoginRegion.ToLower() + ".beanfun.com/"));
        }

        private string GetCookie(string cookieName)
        {
            foreach (Cookie cookie in GetCookies())
            {
                if (cookie.Name == cookieName)
                {
                    return cookie.Value;
                }
            }
            return null;
        }

        private string GetCurrentTime(int method = 0)
        {
            DateTime date = DateTime.Now;
            switch (method)
            {
                case 1:
                    return (date.Year - 1900).ToString() + (date.Month - 1).ToString() + date.ToString("ddHHmmssfff");
                case 2:
                    return date.Year.ToString() + (date.Month - 1).ToString() + date.ToString("ddHHmmssfff");
                default:
                    return date.ToString("yyyyMMddHHmmss.fff");
            }
        }

        public void Ping()
        {
            string ret;

            try
            {
                if (App.LoginRegion == "TW")
                {
                    ret = Encoding.GetString(this.DownloadData("https://tw.beanfun.com/beanfun_block/generic_handlers/echo_token.ashx?webtoken=1"));
                }
                else
                {
                    if (bfServ == null)
                        return;
                    ret = this.DownloadString("http://hk.beanfun.com/beanfun_block/generic_handlers/echo_token.ashx?token=" + bfServ.Token);
                }

                Console.WriteLine(GetCurrentTime() + " @ " + ret);
            } catch {
            }
        }

        public int getRemainPoint()
        {
            string response = null;
            System.Text.RegularExpressions.Regex regex;

            string url = "https://tw.beanfun.com/beanfun_block/generic_handlers/get_remain_point.ashx?webtoken=1";
            if (App.LoginRegion == "HK")
                url = "http://hk.beanfun.com/beanfun_block/generic_handlers/get_remain_point.ashx?token=" + bfServ.Token;
            response = this.DownloadString(url);

            try
            {
                regex = new System.Text.RegularExpressions.Regex("\"RemainPoint\" : \"(.*)\" }");
                if (regex.IsMatch(response))
                    return int.Parse(regex.Match(response).Groups[1].Value);
                else
                    return 0;
            }
            catch
            { return 0; }
        }


        public string getEmail()
        {
            if (App.LoginRegion == "HK")
                return "";

            this.Headers.Set("Referer", @"https://tw.beanfun.com/");
            string response = this.DownloadString("https://tw.beanfun.com/beanfun_block/loader.ashx?service_code=999999&service_region=T0");
            System.Text.RegularExpressions.Regex regex = new System.Text.RegularExpressions.Regex("BeanFunBlock.LoggedInUserData.Email = \"(.*)\";BeanFunBlock.LoggedInUserData.MessageCount");
            if (regex.IsMatch(response))
                return regex.Match(response).Groups[1].Value;
            else
                return "";
        }
    }
}
