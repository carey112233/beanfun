﻿using System;
using System.IO;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;

namespace Beanfun
{
    /// <summary>
    /// MapleTools.xaml 的交互逻辑
    /// </summary>
    public partial class MapleTools : Window
    {
        public MapleTools()
        {
            InitializeComponent();
            if (!App.IsWin10) SourceChord.FluentWPF.AcrylicWindow.SetTintOpacity(this, 1.0);
        }
        BeanfunClient bf = new BeanfunClient();
        private void Window_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            this.DragMove();
        }
        private void btn_Bahamute_Click(object sender, RoutedEventArgs e)
        {
            bf.DownloadFirefox("https://forum.gamer.com.tw/B.php?bsn=7650");
        }


        private void btn_PlayerLink_Click(object sender, RoutedEventArgs e)
        {
            Task t = new Task(() =>
            {
                try
                {

                    string Uri_s = ConfigAppSettings.GetValue("Link_Uri", null);
                    if (Uri_s == null || Uri_s == "")
                    {
                        WebClient web = new WebClient();
                        Uri uri = new Uri("https://gitee.com/Carey1223/bean-men/blob/master/README.md");
                        string s = Encoding.UTF8.GetString(web.DownloadData(uri));
                        Regex regex = new Regex("link地址：(.*)结束9");
                        try
                        {
                            if (!regex.IsMatch(s))
                            { }
                            string response;
                            response = regex.Match(s).Groups[1].Value;
                            ConfigAppSettings.SetValue("Link_Uri", response);

                            bf.DownloadFirefox(response);



                        }
                        catch
                        {

                        }

                    }
                    else
                    {
                        bf.DownloadFirefox(Uri_s);
                        WebClient web = new WebClient();
                        Uri uri = new Uri("https://gitee.com/Carey1223/bean-men/blob/master/README.md");
                        string s = Encoding.UTF8.GetString(web.DownloadData(uri));
                        Regex regex = new Regex("link地址：(.*)结束9");
                        try
                        {
                            if (!regex.IsMatch(s))
                            { }
                            string response;
                            response = regex.Match(s).Groups[1].Value;
                            ConfigAppSettings.SetValue("Link_Uri", response);

                        }
                        catch
                        {
                        }

                    }

                }
                catch { }


                Thread.Sleep(50);
            });
            t.Start();
        }
        private void btn_Fudai_Click(object sender, RoutedEventArgs e)
        {
            Task t = new Task(() =>
            {
                try
                {

                    string Uri_s = ConfigAppSettings.GetValue("Fudai_Uri", null);
                    if (Uri_s == null || Uri_s == "")
                    {
                        WebClient web = new WebClient();
                        Uri uri = new Uri("https://gitee.com/Carey1223/bean-men/blob/master/README.md");
                        string s = Encoding.UTF8.GetString(web.DownloadData(uri));
                        Regex regex = new Regex("福袋地址：(.*)结束11");
                        try
                        {
                            if (!regex.IsMatch(s))
                            { }
                            string response;
                            response = regex.Match(s).Groups[1].Value;
                            ConfigAppSettings.SetValue("Fudai_Uri", response);

                            bf.DownloadFirefox(response);



                        }
                        catch
                        {

                        }

                    }
                    else
                    {
                        bf.DownloadFirefox(Uri_s);
                        WebClient web = new WebClient();
                        Uri uri = new Uri("https://gitee.com/Carey1223/bean-men/blob/master/README.md");
                        string s = Encoding.UTF8.GetString(web.DownloadData(uri));
                        Regex regex = new Regex("福袋地址：(.*)结束11");
                        try
                        {
                            if (!regex.IsMatch(s))
                            { }
                            string response;
                            response = regex.Match(s).Groups[1].Value;
                            ConfigAppSettings.SetValue("Fudai_Uri", response);

                        }
                        catch
                        {
                        }

                    }

                }
                catch { }


                Thread.Sleep(50);
            });
            t.Start();

        }
        private void btn_VideoReport_Click(object sender, RoutedEventArgs e)
        {

            Task t = new Task(() =>
            {

                bf.DownloadFirefox("https://www.bilibili.com/video/BV16x41157E6?from=search&seid=722419876486568090");

                Thread.Sleep(50);
            });
            t.Start();
        }

        private void btn_EquipCalculator_Click(object sender, RoutedEventArgs e)
        {
            new EquipCalculator().Show();
        }
        private void btn_8591_Click(object sender, RoutedEventArgs e)
        {
            Task t = new Task(() =>
            {
                try
                {

                    string Uri_s = ConfigAppSettings.GetValue("Jiaoyi_Uri", null);
                    if (Uri_s == null || Uri_s == "")
                    {
                        WebClient web = new WebClient();
                        Uri uri = new Uri("https://gitee.com/Carey1223/bean-men/blob/master/README.md");
                        string s = Encoding.UTF8.GetString(web.DownloadData(uri));
                        Regex regex = new Regex("交易网站：(.*)结束8");
                        try
                        {
                            if (!regex.IsMatch(s))
                            { }
                            string response;
                            response = regex.Match(s).Groups[1].Value;
                            ConfigAppSettings.SetValue("Jiaoyi_Uri", response);

                            bf.DownloadFirefox(response);



                        }
                        catch
                        {

                        }

                    }
                    else
                    {
                        bf.DownloadFirefox(Uri_s);
                        WebClient web = new WebClient();
                        Uri uri = new Uri("https://gitee.com/Carey1223/bean-men/blob/master/README.md");
                        string s = Encoding.UTF8.GetString(web.DownloadData(uri));
                        Regex regex = new Regex("交易网站：(.*)结束8");
                        try
                        {
                            if (!regex.IsMatch(s))
                            { }
                            string response;
                            response = regex.Match(s).Groups[1].Value;
                            ConfigAppSettings.SetValue("Jiaoyi_Uri", response);

                        }
                        catch
                        {
                        }

                    }

                }
                catch { }


                Thread.Sleep(50);
            });
            t.Start();
        }
        private void btn_Huodong_Click(object sender, RoutedEventArgs e)
        {
            Task t = new Task(() =>
            {
                try
                {

                    string Uri_s=ConfigAppSettings.GetValue("Huodong_Uri", null);
                    if (Uri_s == null || Uri_s == "")
                    {
                        WebClient web = new WebClient();
                        Uri uri = new Uri("https://gitee.com/Carey1223/bean-men/blob/master/README.md");
                        string s = Encoding.UTF8.GetString(web.DownloadData(uri));
                        Regex regex = new Regex("最新活动地址：(.*)结束4");
                        try
                        {
                            if (!regex.IsMatch(s))
                            { }
                            string response;
                            response = regex.Match(s).Groups[1].Value;
                            ConfigAppSettings.SetValue("Huodong_Uri", response);

                            bf.DownloadFirefox(response);



                        }
                        catch
                        {

                        }

                    }
                    else
                    {
                        bf.DownloadFirefox(Uri_s);
                        WebClient web = new WebClient();
                        Uri uri = new Uri("https://gitee.com/Carey1223/bean-men/blob/master/README.md");
                        string s = Encoding.UTF8.GetString(web.DownloadData(uri));
                        Regex regex = new Regex("最新活动地址：(.*)结束4");
                        try
                        {
                            if (!regex.IsMatch(s))
                            { }
                            string response;
                            response = regex.Match(s).Groups[1].Value;
                            ConfigAppSettings.SetValue("Huodong_Uri", response);

                        }
                        catch
                        {
                        }

                    }

                }
                catch { }


                Thread.Sleep(50);
            });
            t.Start();
        }
          
    }
}
